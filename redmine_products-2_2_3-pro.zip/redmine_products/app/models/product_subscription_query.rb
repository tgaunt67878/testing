# This file is a part of Redmine Products (redmine_products) plugin,
# customer relationship management plugin for Redmine
#
# Copyright (C) 2011-2024 RedmineUP
# http://www.redmineup.com/
#
# redmine_products is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_products is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_products.  If not, see <http://www.gnu.org/licenses/>.

class ProductSubscriptionQuery < Query
  include CrmQuery

  self.queried_class = ProductSubscription
  self.view_permission = :view_subscriptions

  self.available_columns = [
    QueryColumn.new(:created_at, sortable: "#{ProductSubscription.table_name}.created_at", default_order: 'desc', caption: :field_created_on),
    QueryColumn.new(:updated_at, sortable: "#{ProductSubscription.table_name}.updated_at", default_order: 'desc', caption: :field_updated_on),
  ]

  def initialize(attributes = nil, *_args)
    super attributes
    self.filters ||= {'fine' => {:operator => "=", :values => ["1"]}}
  end

  def initialize_available_filters
    add_available_filter 'fine', type: :list, values: [[l(:general_text_yes), "1"], [l(:general_text_no), "0"]], label: :label_product_subscriptions_fine
    add_available_filter 'created_at', type: :date_past, label: :field_created_on
    add_available_filter 'updated_at', type: :date_past, label: :field_updated_on

    initialize_author_filter

    add_available_filter 'tags', type: :product_tags,
                         values: Product.available_tags(project.blank? ? {} : { project: project.id }).map { |t| [t.name, t.name] }
  end

  def available_columns
    return @available_columns if @available_columns

    @available_columns = self.class.available_columns.dup
    @available_columns += CustomField.where(type: 'ProductCustomField').all.map { |cf| QueryCustomFieldColumn.new(cf) }
    @available_columns
  end

  def default_columns_names
    @default_columns_names ||= [:created_at, :updated_at]
  end

  def sql_for_project_field(field, operator, value)
    '(' + sql_for_field(field, operator, value, Project.table_name, "id", false) + ')'
  end

  def sql_for_fine_field(_field, operator, value)
    condition =
      case operator
      when '='
        value.join.to_i == 1 ? '>' : '<'
      when '!'
        value.join.to_i == 0 ? '>' : '<'
      end

    condition ? "(#{queried_table_name}.expire_date #{condition} '#{Date.today + 1.day}')" : '1=1'
  end

  def objects_scope(options = {})
    scope = ProductSubscription.visible
    options[:search].split(' ').collect{ |search_string| scope = scope.live_search(search_string) } unless options[:search].blank?
    scope = scope.includes((query_includes + (options[:include] || [])).uniq).
                  where(statement).
                  where(options[:conditions])
    scope
  end

  def query_includes
    includes = [:project]
    includes << :tags if self.filters['tags']
    includes
  end

end
