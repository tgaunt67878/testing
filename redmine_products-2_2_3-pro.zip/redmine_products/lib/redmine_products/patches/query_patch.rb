# This file is a part of Redmine Products (redmine_products) plugin,
# customer relationship management plugin for Redmine
#
# Copyright (C) 2011-2024 RedmineUP
# http://www.redmineup.com/
#
# redmine_products is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_products is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_products.  If not, see <http://www.gnu.org/licenses/>.

require_dependency 'query'

module RedmineProducts
  module Patches
    module QueryPatch
      def self.included(base)
        base.send(:include, InstanceMethods)
        base.class_eval do
          alias_method :add_filter_without_products, :add_filter
          alias_method :add_filter, :add_filter_with_products

          alias_method :add_available_filter_without_products, :add_available_filter
          alias_method :add_available_filter, :add_available_filter_with_products
        end
      end

      module InstanceMethods
        def add_available_filter_with_products(field, options)
          add_available_filter_without_products(field, options)
          values = filters[field].blank? ? [] : filters[field][:values]
          initialize_values_for_select2_with_products(field, values)
          @available_filters
        end

        def add_filter_with_products(field, operator, values = nil)
          add_filter_without_products(field, operator, values)
          return unless available_filters[field]

          initialize_values_for_select2_with_products(field, values)
          true
        end

        def initialize_values_for_select2_with_products(field, values)
          case @available_filters[field][:type]
          when :product
            @available_filters[field][:values] = values.blank? ? [] : ids_to_names_with_ids_with_products(values, Product)
          when :order
            @available_filters[field][:values] = values.blank? ? [] : ids_to_names_with_ids_with_products(values, Order)
          end
        end

        def ids_to_names_with_ids_with_products(ids, model)
          ids.blank? ? [] : model.where(:id => ids).map { |r| [r.to_s, r.id.to_s] }
        end
      end
    end
  end
end

unless Query.included_modules.include?(RedmineProducts::Patches::QueryPatch)
  Query.send(:include, RedmineProducts::Patches::QueryPatch)
end
