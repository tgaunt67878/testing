# This file is a part of Redmine Helpdesk (redmine_helpdesk) plugin,
# customer support management plugin for Redmine
#
# Copyright (C) 2011-2024 RedmineUP
# http://www.redmineup.com/
#
# redmine_helpdesk is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_helpdesk is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_helpdesk.  If not, see <http://www.gnu.org/licenses/>.

class HelpdeskMailRecipient::IssueReplyRecipient < HelpdeskMailRecipient
  def receive(issue_id)
    issue = Issue.where(id: issue_id).first
    return unless issue
    return receive_new_issue if HelpdeskSettings['helpdesk_lifetime', project].present? &&
                                HelpdeskSettings['helpdesk_lifetime', project].to_i >= 0 &&
                                lifetime_expired?(issue)

    journal = issue.init_journal(container.from_user)
    journal.notes = container.text_body
    journal_message = JournalMessage.create(from_address: slice_emails(container.from_addr.downcase),
                                            to_address: slice_emails(email.to_addrs.join(',').downcase),
                                            bcc_address: slice_emails(email.bcc_addrs.join(',').downcase),
                                            cc_address: slice_emails((to_recipients + except_service_emails(email.cc_addrs)).join(',').downcase.to_s),
                                            message_id: email.message_id,
                                            is_incoming: true,
                                            message_date: email.date || Time.now,
                                            contact: contact,
                                            journal: journal)

    add_attachments(issue)
    save_email_as_calendar(issue)
    save_email_as_attachment(journal_message, "reply-#{DateTime.now.strftime('%d.%m.%y-%H.%M.%S')}.eml")
    issue.status_id = reopen_status_id if reopen_status_id

    issue.save!(:validate => false)
    container.issue = issue.reload
    HelpdeskMailRule.apply_rules(:incoming, container)

    logger.try(:info, "#{email.message_id}: issue ##{issue.id} updated by #{container.from_user}")
    journal
  end

  private

  def receive_new_issue
    email.subject = email.subject.to_s.gsub(MailHandler::ISSUE_REPLY_SUBJECT_RE, '')
    HelpdeskMailRecipient::IssueRecipient.new(container).receive
  end

  def reopen_status_id
    IssueStatus.named(get_keyword(:reopen_status)).first.try(:id) || IssueStatus.where(id: get_keyword(:reopen_status_id)).first.try(:id)
  end

  def lifetime_expired?(issue)
    last_date = (issue.journals.last || issue).created_on.to_date
    Date.today - last_date >= HelpdeskSettings['helpdesk_lifetime', project].to_i
  end
end
