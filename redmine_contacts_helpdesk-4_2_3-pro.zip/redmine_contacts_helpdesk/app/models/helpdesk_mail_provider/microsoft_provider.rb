# This file is a part of Redmine Helpdesk (redmine_helpdesk) plugin,
# customer support management plugin for Redmine
#
# Copyright (C) 2011-2024 RedmineUP
# http://www.redmineup.com/
#
# redmine_helpdesk is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_helpdesk is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_helpdesk.  If not, see <http://www.gnu.org/licenses/>.

class HelpdeskMailProvider::MicrosoftProvider < HelpdeskMailProvider
  def check
    msg_count = 0
    oauth_provider = HelpdeskOauthProvider::Microsoft.new(mail_options[:project_id])
    folder = mail_options[:folder]
    success_folder = mail_options[:move_on_success]
    fail_folder = mail_options[:move_on_failure]

    oauth_provider.messages(folder).each do |mid, msg|
      logger.info "HelpdeskMailProvider::MicrosoftProvider: Receiving message #{mid}" if logger && logger.info?
      msg_count += 1
      oauth_provider.read_message(mid)
      if self.receive(msg, options)
        logger.info "HelpdeskMailProvider::MicrosoftProvider: Message #{mid} successfully received" if logger && logger.info?
        oauth_provider.move_message(mid, success_folder) if success_folder && success_folder != folder
      else
        logger.info "HelpdeskMailProvider::MicrosoftProvider: Message #{mid} can not be processed" if logger && logger.info?
        oauth_provider.move_message(mid, fail_folder) if fail_folder && fail_folder != folder
      end
    end
    msg_count
  end
end
