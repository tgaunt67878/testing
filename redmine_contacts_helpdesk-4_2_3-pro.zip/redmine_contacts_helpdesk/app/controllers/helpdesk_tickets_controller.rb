# This file is a part of Redmine Helpdesk (redmine_helpdesk) plugin,
# customer support management plugin for Redmine
#
# Copyright (C) 2011-2024 RedmineUP
# http://www.redmineup.com/
#
# redmine_helpdesk is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_helpdesk is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_helpdesk.  If not, see <http://www.gnu.org/licenses/>.

class HelpdeskTicketsController < HelpdeskBaseController
  before_action :find_issue, except: [:index, :create, :bulk_edit_reply, :bulk_update_reply, :preview_bulk_reply]
  before_action :find_project, except: [:index, :bulk_edit_reply, :bulk_update_reply, :preview_bulk_reply]
  before_action :authorize, except: [:index, :preview_bulk_reply, :bulk_edit_reply, :bulk_update_reply]
  before_action :find_helpdesk_ticket, only: [:show, :edit, :update, :destroy]
  before_action :find_optional_project, only: [:index]
  before_action :find_issues, only: [:bulk_edit_reply, :bulk_update_reply]

  accept_api_auth :index, :create, :show, :update, :destroy

  helper :helpdesk
  helper :helpdesk_api
  helper :attachments
  helper :queries
  include QueriesHelper

  def index
    retrieve_query(HelpdeskTicketQuery)

    if @query.valid?
      respond_to do |format|
        format.api  {
          @offset, @limit = api_offset_and_limit
          @tickets_count = @query.tickets_count
          @tickets = @query.tickets(offset: @offset, limit: @limit)
          Issue.load_visible_relations(@issues) if include_in_api_response?('relations')
        }
        format.any { head 200 }
      end
    else
      respond_to do |format|
        format.any(:atom, :csv, :pdf) { head 422 }
        format.api { render_validation_errors(@query) }
      end
    end
  rescue ActiveRecord::RecordNotFound
    render_404
  end

  def create
    return unless validate_create_params

    @issue = Issue.new
    @issue.project = @project
    @issue.author ||= User.current
    @issue.safe_attributes = params[:helpdesk_ticket][:issue]

    @contact = Contact.find_by_emails([params[:helpdesk_ticket][:contact][:email]]).first
    unless @contact
      @contact = Contact.new
      @contact.safe_attributes = params[:helpdesk_ticket][:contact]
    end
    @contact.projects << @project unless @contact.projects.include?(@project)

    @helpdesk_ticket = HelpdeskTicket.new(ticket_date: Time.now, customer: @contact, is_incoming: true, issue: @issue)
    @helpdesk_ticket.safe_attributes = params[:helpdesk_ticket].except(:issue, :contact)
    @helpdesk_ticket.from_address = @contact.primary_email
    @helpdesk_ticket.source = find_ticket_source

    @issue.helpdesk_ticket = @helpdesk_ticket
    @issue.assigned_to = @contact.find_assigned_user(@project, @issue.assigned_to)
    @issue.save_attachments(params[:helpdesk_ticket][:attachments] || (params[:helpdesk_ticket][:issue] && params[:helpdesk_ticket][:issue][:uploads]))

    if @issue.save
      process_helpdesk_send_as(params[:helpdesk_ticket][:send_as])
      HelpdeskTicket.autoclose(@project)
      return render_api_view(action: :create, status: :created)
    else
      return render_api_error(message: @issue.errors.full_messages)
    end
  rescue Exception => e
    render_api_error(message: "#{e.message} (#{e.backtrace.first})")
  end

  def show
    @show_form = 'false'
    respond_to do |format|
      format.js
      format.api
    end
  end

  def edit
    @helpdesk_ticket = @issue.helpdesk_ticket || @issue.build_helpdesk_ticket(ticket_date: Time.now)

    @show_form = 'true'
    respond_to do |format|
      format.js
    end
  end

  def update
    @helpdesk_ticket.safe_attributes = params[:helpdesk_ticket]
    if params[:helpdesk_ticket][:cc_address]
      cc_address = params[:helpdesk_ticket][:cc_address]
      cc_address = cc_address.reject(&:empty?).join(',') if cc_address.is_a?(Array)
      @helpdesk_ticket.cc_address = cc_address
    end
    if params[:helpdesk_ticket][:from_address].present?
      from_param = params[:helpdesk_ticket][:from_address]
      if from_param =~ /^\d+$/
        customer = Contact.where(id: from_param).first
        @helpdesk_ticket.customer = customer
        @helpdesk_ticket.from_address = customer.try(:primary_email)
      else
        @helpdesk_ticket.customer = HelpdeskMailSupport.create_contact_from_address(from_param, from_param, @project)
      end
    else
      @helpdesk_ticket.from_address = @helpdesk_ticket.customer.try(:primary_email)
    end
    @helpdesk_ticket.source = find_ticket_source if params[:helpdesk_ticket][:source]

    if @helpdesk_ticket.save
      flash[:notice] = l(:notice_successful_update)
      respond_to do |format|
        format.html { redirect_back_or_default(issue_path(@issue)) }
        format.api  { render_api_view(action: :show, status: 200) }
      end
    else
      flash[:error] = @helpdesk_ticket.errors.full_messages.flatten.join("\n")
      respond_to do |format|
        format.html { redirect_back_or_default(issue_path(@issue)) }
        format.api  { render_api_error(message: @issue.errors.full_messages) }
      end
    end
  end

  def destroy
    if @helpdesk_ticket.destroy
      flash[:notice] = l(:notice_successful_delete)
      respond_to do |format|
        format.html { redirect_back_or_default(issue_path(@issue)) }
        format.api { render_api_view(status: :no_content) }
      end
    else
      flash[:error] = l(:notice_unsuccessful_save)
      respond_to do |format|
        format.html { redirect_back_or_default(issue_path(@issue)) }
        format.api  { render_api_error(message: @helpdesk_ticket.errors.full_messages) }
      end
    end
  end

  def bulk_edit_reply
    @project = Project.find(params[:project_id])
    @contacts = @issues.map { |issue| issue.helpdesk_ticket.try(:contact_id) }

    unless @issues.all?(&:is_ticket?)
      render_404
    else
      render 'bulk_reply'
    end
  end

  def bulk_update_reply
    unsaved_issues = []

    @issues.each do |issue|
      journal = issue.init_journal(User.current, params[:notes])

      to_address = issue.helpdesk_ticket.default_to_address
      cc = params[:journal_message][:cc_address]
      bcc = params[:journal_message][:bcc_address]

      options = params.merge(journal_message: { to_address: [to_address], cc_address: [cc], bcc_address: [bcc] })

      if issue.helpdesk_ticket && params[:helpdesk] && params[:helpdesk][:is_send_mail].present? && User.current.allowed_to?(:send_response, issue.project)
        HelpdeskTicket.send_reply_by_issue(issue, options)
      end

      unsaved_issues << issue unless issue.save
    end

    if unsaved_issues.empty?
      flash[:notice] = l(:notice_successful_update)
      redirect_back_or_default(bulk_edit_reply_helpdesk_tickets_path(ids: @issues.ids))
    else
      bulk_edit_reply
      render :action => 'bulk_edit_reply'
    end

  end

  def preview_bulk_reply
    contact = params[:ids].present? ? Contact.visible.where(id: params[:ids][0]).first : nil
    @text = contact.nil? ? params[:text] : mail_macro(contact, params[:text])
    render :partial => 'common/preview'
  end

  private

  def find_issue
    # TODO: Remove params[:issue_id] when new API will be applied
    @issue = Issue.find(params[:issue_id] || params[:id])
  rescue ActiveRecord::RecordNotFound
    render_api_error(message: 'Issue not found', status: :not_found)
  end

  def find_issues
    @issues = Issue.where(id: (params[:ids] || params[:issue]))
    render_404 if @issues.empty?
  end

  def find_project
    return @project = @issue.project if @issue

    project_id = params[:helpdesk_ticket] && params[:helpdesk_ticket][:issue] && params[:helpdesk_ticket][:issue][:project_id]
    @project = Project.find_by_param(project_id)
  rescue ActiveRecord::RecordNotFound
    return render_api_error(message: 'Project not found', status: :not_found) unless @project
  end

  def find_helpdesk_ticket
    @helpdesk_ticket = @issue.helpdesk_ticket
    @helpdesk_ticket ||= @issue.build_helpdesk_ticket(ticket_date: Time.now) unless request.format.api?
    return render_api_error(message: 'Helpdesk ticket not found', status: :not_found) unless @helpdesk_ticket
  end

  def validate_create_params
    return render_api_error(message: 'HelpdeskTicket params cannot be blank') if params[:helpdesk_ticket].blank?
    return render_api_error(message: 'Issue params cannot be blank') if params[:helpdesk_ticket][:issue].blank?
    return render_api_error(message: 'Contact params cannot be blank') if params[:helpdesk_ticket][:contact].blank?
    return render_api_error(message: 'Contact should have email address') if params[:helpdesk_ticket][:contact][:email].blank?

    true
  end

  def find_ticket_source
    case params[:helpdesk_ticket][:source]
    when 'email', '0'
      HelpdeskTicket::HELPDESK_EMAIL_SOURCE
    when 'web', '1'
      HelpdeskTicket::HELPDESK_WEB_SOURCE
    when 'phone', '2'
      HelpdeskTicket::HELPDESK_PHONE_SOURCE
    when 'twitter', '3'
      HelpdeskTicket::HELPDESK_TWITTER_SOURCE
    when 'conversation', '4'
      HelpdeskTicket::HELPDESK_CONVERSATION_SOURCE
    else
      HelpdeskTicket::HELPDESK_WEB_SOURCE
    end
  end

  def render_api_view(opts)
    status = opts[:status] || 200
    respond_to do |format|
      format.api  do
        return head status if opts[:action].blank?
        render action: opts[:action], status: status
      end
      format.any { head status }
    end
    true
  end

  def render_api_error(opts)
    @message = opts[:message]
    @error_messages = [opts[:message]]
    @status = opts[:status] || :unprocessable_entity
    respond_to do |format|
      format.html do
        render_404
      end
      format.api do
        render template: 'common/error_messages', format: [:api], status: @status
      end
      format.any { head @status }
    end
    false
  end
end
