# This file is a part of Redmine Helpdesk (redmine_helpdesk) plugin,
# customer support management plugin for Redmine
#
# Copyright (C) 2011-2024 RedmineUP
# http://www.redmineup.com/
#
# redmine_helpdesk is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_helpdesk is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_helpdesk.  If not, see <http://www.gnu.org/licenses/>.

class HelpdeskOauthController < HelpdeskBaseController
  before_action :find_project, except: [:resp]
  before_action :authorize, except: [:resp]

  def auth
    ContactsSetting[:helpdesk_protocol, @project.id] = params[:provider]
    oauth_provider = build_oauth_provider(params[:provider], @project.id)
    return render_404 unless oauth_provider

    redirect_to oauth_provider.authorize_url(generate_state_secret)
  end

  def auth_remove
    oauth_provider = build_oauth_provider(params[:provider], @project.id)
    return render_404 unless oauth_provider

    oauth_provider.reset_token

    redirect_to settings_project_path(@project, tab: 'helpdesk')
  end

  def resp
    secret_data = extract_secret_data
    return render_404 unless secret_data

    oauth_provider = build_oauth_provider(secret_data[:provider], secret_data[:project])
    oauth_provider.receive_tokens(params[:code])

    redirect_to settings_project_path(secret_data[:project], tab: 'helpdesk')
  end

  private

  def build_oauth_provider(provider, project_id)
    oauth_provider = HelpdeskOauthProvider.find_by_protocol(provider)
    return nil unless oauth_provider

    oauth_provider.new(project_id)
  end

  def find_project
    @project = Project.find_by(identifier: params[:project])
    render_404 unless @project
  end

  def generate_state_secret
    secret = SecureRandom.uuid
    secret_data = { 'project' => @project.id, 'provider' => params[:provider] }

    state_secrets = RedmineHelpdesk.settings['helpdesk_oauth_state_secrets'] || {}
    old_secret = state_secrets.key(secret_data)
    state_secrets.delete(old_secret) if old_secret
    RedmineHelpdesk.settings = { 'helpdesk_oauth_state_secrets' => state_secrets.merge(secret => secret_data) }

    secret
  end

  def extract_secret_data
    state_secrets = RedmineHelpdesk.settings['helpdesk_oauth_state_secrets'] || {}
    data = state_secrets[params[:state]]
    return unless data

    state_secrets.delete(params[:state])
    RedmineHelpdesk.settings = { 'helpdesk_oauth_state_secrets' => state_secrets }

    data
  end
end
