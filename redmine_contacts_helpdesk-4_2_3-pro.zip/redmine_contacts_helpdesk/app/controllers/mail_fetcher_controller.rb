# This file is a part of Redmine Helpdesk (redmine_helpdesk) plugin,
# customer support management plugin for Redmine
#
# Copyright (C) 2011-2024 RedmineUP
# http://www.redmineup.com/
#
# redmine_helpdesk is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_helpdesk is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_helpdesk.  If not, see <http://www.gnu.org/licenses/>.

class MailFetcherController < ApplicationController
  require 'timeout'
  require 'redmine/imap.rb'

  before_action :check_credential

  def receive_imap
    imap_options = { :host => params['host'],
                     :port => params['port'],
                     :ssl => params['ssl'],
                     :username => params['username'],
                     :password => params['password'],
                     :folder => params['folder'],
                     :move_on_success => params['move_on_success'],
                     :move_on_failure => params['move_on_failure'] }

    options = { :issue => {} }
    %w(project status tracker category priority).each { |a| options[:issue][a.to_sym] = params[a] if params[a] }
    options[:allow_override] = params['allow_override'] if params['allow_override']
    options[:unknown_user] = params['unknown_user'] if params['unknown_user']
    options[:no_permission_check] = params['no_permission_check'] if params['no_permission_check']

    begin
      Timeout::timeout(15) { Redmine::IMAP.check(imap_options, options) }
    rescue Exception => e
      @error_messages = [e.message]
    end

    if @error_messages.blank?
      respond_to do |format|
        format.html { head :ok }
        format.api { render_api_ok }
      end
    else
      respond_to do |format|
        response_key = :plain
        format.html { render response_key => @error_messages, :status => :unprocessable_entity, :layout => nil }
        format.api { render template: 'common/error_messages', status: :unprocessable_entity, layout: nil }
      end
    end
  end

  def receive_pop3
    pop_options = { :host => params['host'],
                    :port => params['port'],
                    :apop => params['apop'],
                    :username => params['username'],
                    :password => params['password'],
                    :delete_unprocessed => params['delete_unprocessed'] }

    options = { :issue => {} }
    %w(project status tracker category priority).each { |a| options[:issue][a.to_sym] = params[a] if params[a] }
    options[:allow_override] = params['allow_override'] if params['allow_override']
    options[:unknown_user] = params['unknown_user'] if params['unknown_user']
    options[:no_permission_check] = params['no_permission_check'] if params['no_permission_check']

    begin
      Timeout::timeout(15) { Redmine::POP3.check(pop_options, options) }
    rescue Exception => e
      @error_messages = [e.message]
    end

    if @error_messages.blank?
      respond_to do |format|
        format.html { render :nothing => true, :status => :ok }
        format.api { render_api_ok }
      end
    else
      respond_to do |format|
        format.html { render :text => @error_messages, :status => :unprocessable_entity, :layout => nil }
        format.api { render template: 'common/error_messages', status: :unprocessable_entity, layout: nil }
      end
    end
  end

  private

  def check_credential
    User.current = nil
    unless Setting.mail_handler_api_enabled? && params[:key].to_s == Setting.mail_handler_api_key
      render :text => 'Access denied. Incoming emails WS is disabled or key is invalid.', :status => 403
    end
  end

end
