# This file is a part of Redmine Helpdesk (redmine_helpdesk) plugin,
# customer support management plugin for Redmine
#
# Copyright (C) 2011-2024 RedmineUP
# http://www.redmineup.com/
#
# redmine_helpdesk is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_helpdesk is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_helpdesk.  If not, see <http://www.gnu.org/licenses/>.

class PublicTicketsController < ApplicationController
  layout 'public_tickets'

  skip_before_action :check_if_login_required
  before_action :find_ticket, :authorize_ticket

  helper :issues
  helper :attachments
  helper :journals
  helper :custom_fields

  def show
    @previous_tickets = @ticket.customer.tickets.where(:is_private => false).includes([:status, :helpdesk_ticket]).order_by_status

    @total_spent_hours = @previous_tickets.map.sum(&:total_spent_hours)

    @journals = @issue.journals.includes(:user).
                       includes(:details).
                       order("#{Journal.table_name}.created_on ASC").
                       where(:private_notes => false).
                       where("EXISTS (SELECT * FROM #{JournalMessage.table_name} WHERE #{JournalMessage.table_name}.journal_id = #{Journal.table_name}.id)")
    @journals = @journals.each_with_index { |j, i| j.indice = i + 1 }.to_a
    @journals.reverse! if User.current.wants_comments_in_reverse_order?
    @journal = @issue.journals.new

    @allowed_statuses = @issue.new_statuses_allowed_to(User.current)
    @edit_allowed = User.current.allowed_to?(:edit_issues, @project)
    @priorities = IssuePriority.active
    @time_entry = TimeEntry.new(:issue => @issue, :project => @issue.project)
    prepend_view_path 'app/views/issues'
  end

  def add_comment
    @journal = @issue.init_journal(User.current, params[:journal][:notes])
    @issue.status_id = HelpdeskSettings['helpdesk_reopen_status', @issue.project_id] unless HelpdeskSettings['helpdesk_reopen_status', @issue.project_id].blank?
    @journal.journal_message = JournalMessage.new(:from_address => @ticket.customer_email,
                                                  :contact => @ticket.customer,
                                                  :journal => @journal,
                                                  :is_incoming => true,
                                                  :message_date => Time.now)

    flash[:notice] = l(:notice_successful_create) if @issue.save
    redirect_back_or_default(public_ticket_path(@ticket, @ticket.token))
  end

  def render_404(_options = {})
    @message = l(:notice_file_not_found)
    respond_to do |format|
      format.html { render :template => 'common/error', :status => 404 }
      format.any { head 404 }
    end
    false
  end

  private

  def find_ticket
    @ticket = HelpdeskTicket.find(params[:id])
    @issue = @ticket.issue
    @project = @issue.project
  rescue ActiveRecord::RecordNotFound
    render_404
  end

  def authorize_ticket(action = params[:action])
    allow = true
    allow &&= RedmineHelpdesk.public_comments? if action.to_s == 'add_comment'
    allow &&= (@ticket.token == params[:hash]) && RedmineHelpdesk.public_tickets?
    allow &&= !@issue.is_private
    render_404 unless allow
  end
end
