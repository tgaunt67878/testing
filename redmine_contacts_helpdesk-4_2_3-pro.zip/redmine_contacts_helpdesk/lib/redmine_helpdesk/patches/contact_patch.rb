# This file is a part of Redmine Helpdesk (redmine_helpdesk) plugin,
# customer support management plugin for Redmine
#
# Copyright (C) 2011-2024 RedmineUP
# http://www.redmineup.com/
#
# redmine_helpdesk is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_helpdesk is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_helpdesk.  If not, see <http://www.gnu.org/licenses/>.

module RedmineHelpdesk
  module Patches
    module ContactPatch
      def self.included(base) # :nodoc:
        base.send(:include, InstanceMethods)
        base.class_eval do
          has_many :journal_messages, :dependent => :destroy
          has_many :journals, :through => :journal_messages

          has_many :helpdesk_tickets, :dependent => :destroy
          has_many :tickets, :through => :helpdesk_tickets, :source => :issue # class_name => "Issue", :as  => :issue, :foreign_key => 'issue_id'

          def tickets_count
            tickets.count
          end
        end
      end

      module InstanceMethods
        def mail
          primary_email
        end

        def email_name
          [name, ' <', mail, '>'].join
        end

        def bracket_name
          return name if mail.blank?
          [name, ' (', mail, ')'].join
        end

        def all_tickets
          if is_company
            Issue.eager_load(:customer).where(:contacts => { :id => [id] | company_contacts.map(&:id) })
          else
            tickets
          end
        end

        def find_assigned_user(project, current_assigned_id)
          current_assigned_id ||= HelpdeskSettings['helpdesk_assigned_to', project]
          return Principal.find_by_id(current_assigned_id) unless RedmineHelpdesk.assign_contact_user?
          return assigned_to if assigned_to.present? && assigned_to.projects.include?(project)
          return contact_company.assigned_to if contact_company.present? && contact_company.assigned_to.present? &&
                                                contact_company.assigned_to.projects.include?(project)
          Principal.find_by_id(current_assigned_id)
        end
      end
    end
  end
end

unless Contact.included_modules.include?(RedmineHelpdesk::Patches::ContactPatch)
  Contact.send(:include, RedmineHelpdesk::Patches::ContactPatch)
end
