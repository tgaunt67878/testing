# This file is a part of Redmine Helpdesk (redmine_helpdesk) plugin,
# customer support management plugin for Redmine
#
# Copyright (C) 2011-2024 RedmineUP
# http://www.redmineup.com/
#
# redmine_helpdesk is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_helpdesk is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_helpdesk.  If not, see <http://www.gnu.org/licenses/>.

require_dependency 'application_helper'

module RedmineHelpdesk
  module Patches
    module ApplicationHelperPatch
      def self.included(base)
        base.send(:include, InstanceMethods)

        base.class_eval do
          if Redmine::VERSION.to_s < '4.0.4'
            alias_method :avatar_without_helpdesk, :avatar
            alias_method :avatar, :avatar_with_helpdesk
          end

          alias_method :link_to_user_without_helpdesk, :link_to_user
          alias_method :link_to_user, :link_to_user_with_helpdesk
        end
      end

      module InstanceMethods
        def avatar_with_helpdesk(user, options = {})
          if user.is_a?(Contact)
            avatar_to(user, options)
          else
            avatar_without_helpdesk(user, options)
          end
        end

        def link_to_user_with_helpdesk(user, options = {})
          if user.is_a?(Contact)
            link_to_source(user, options)
          else
            link_to_user_without_helpdesk(user, options)
          end
        end
      end
    end
  end
end

unless ApplicationHelper.included_modules.include?(RedmineHelpdesk::Patches::ApplicationHelperPatch)
  ApplicationHelper.send(:include, RedmineHelpdesk::Patches::ApplicationHelperPatch)
end
