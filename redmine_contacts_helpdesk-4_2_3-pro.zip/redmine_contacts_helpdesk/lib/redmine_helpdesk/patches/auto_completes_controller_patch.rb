# This file is a part of Redmine Helpdesk (redmine_helpdesk) plugin,
# customer support management plugin for Redmine
#
# Copyright (C) 2011-2024 RedmineUP
# http://www.redmineup.com/
#
# redmine_helpdesk is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_helpdesk is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_helpdesk.  If not, see <http://www.gnu.org/licenses/>.

require_dependency 'auto_completes_controller'

module RedmineHelpdesk
  module Patches
    module AutoCompletesControllerPatch
      def self.included(base)
        base.send(:include, InstanceMethods)

        base.class_eval do
        end
      end

      module InstanceMethods
        def assignee
          assignee_classes = ['User']
          assignee_classes << 'Group' if Setting.issue_group_assignment?

          scope = Principal.where(type: assignee_classes).limit(100)
          scope = scope.member_of(@project) if @project.present?
          scope = scope.distinct
          @assignee = scope.active.visible.sorted.like(params[:q]).to_a
          @assignee = @assignee.sort! { |x, y| x.name <=> y.name }
          render json: format_assignee_json(@assignee)
        end

        private

        def format_assignee_json(assignee)
          assignee.map do |principal|
            {
              id: principal.id,
              text: principal.name,
              value: principal.id
            }
          end
        end
      end
    end
  end
end

unless AutoCompletesController.included_modules.include?(RedmineHelpdesk::Patches::AutoCompletesControllerPatch)
  AutoCompletesController.send(:include, RedmineHelpdesk::Patches::AutoCompletesControllerPatch)
end
