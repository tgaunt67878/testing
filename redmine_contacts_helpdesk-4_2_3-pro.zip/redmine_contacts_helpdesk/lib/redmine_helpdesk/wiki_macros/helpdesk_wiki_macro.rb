# This file is a part of Redmine Helpdesk (redmine_helpdesk) plugin,
# customer support management plugin for Redmine
#
# Copyright (C) 2011-2024 RedmineUP
# http://www.redmineup.com/
#
# redmine_helpdesk is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_helpdesk is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_helpdesk.  If not, see <http://www.gnu.org/licenses/>.

module RedmineHelpdesk
  module WikiMacros
    module HelpdeskWikiMacro
      Redmine::WikiFormatting::Macros.register do
        desc 'Mail icon Macro'
        macro :mail do |obj, args|
          "<span class=\"icon icon-email\"/>"
        end

        desc 'Helpdesk send_file macro'
        macro :send_file do |obj, args|
          return '' unless obj.is_a?(Issue) || obj.is_a?(Journal)
          issue = obj.is_a?(Journal) ? obj.issue : obj
          return '' unless issue.respond_to?(:customer) || (issue.respond_to?(:customer) && issue.customer.blank?)
          args, options = extract_macro_options(args, :parent)
          raise 'No or bad arguments.' if args.size < 1
          attachment = issue.attachments.where(:filename => args.first).first

          link_to_attachment attachment if attachment
        end
      end
    end
  end
end
