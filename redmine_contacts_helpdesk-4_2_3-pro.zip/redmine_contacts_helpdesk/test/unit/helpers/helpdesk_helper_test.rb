# encoding: utf-8
#
# This file is a part of Redmine Helpdesk (redmine_helpdesk) plugin,
# customer support management plugin for Redmine
#
# Copyright (C) 2011-2024 RedmineUP
# http://www.redmineup.com/
#
# redmine_helpdesk is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_helpdesk is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_helpdesk.  If not, see <http://www.gnu.org/licenses/>.

require File.expand_path('../../../test_helper', __FILE__)

class HelpdeskHelperTest < ActiveSupport::TestCase
  include HelpdeskHelper

  fixtures :projects,
  :users,
  :roles,
  :members,
  :member_roles,
  :issues,
  :issue_statuses,
  :issue_categories,
  :enabled_modules,
  :custom_fields,
  :custom_values,
  :journals,
  :journal_details

  RedmineHelpdesk::TestCase.create_fixtures(Redmine::Plugin.find(:redmine_contacts).directory + '/test/fixtures/', [:contacts,
                                                                                                           :contacts_projects])

  RedmineHelpdesk::TestCase.create_fixtures(Redmine::Plugin.find(:redmine_contacts_helpdesk).directory + '/test/fixtures/', [:journal_messages,
                                                                                                                    :helpdesk_tickets])

  def test_selected_cc_addresses
    ticket1 = HelpdeskTicket.find 1
    ticket4 = HelpdeskTicket.find 4

    assert_equal ticket1.issue.customer.email.downcase, ticket1.default_to_address.downcase
    expected_addresses1 = ticket1.cc_addresses
    cc_addresses1 = selected_cc_addresses(ticket1.issue)
    assert_equal expected_addresses1, cc_addresses1

    assert_not_equal ticket4.issue.customer.email.downcase, ticket4.default_to_address.downcase
    assert_equal [], ticket4.cc_addresses
    expected_addresses4 = [ticket4.issue.customer.email]
    cc_addresses4 = selected_cc_addresses(ticket4.issue)
    assert_equal expected_addresses4, cc_addresses4
  end
end
