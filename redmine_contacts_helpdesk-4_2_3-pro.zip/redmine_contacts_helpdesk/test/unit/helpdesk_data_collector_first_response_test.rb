# encoding: utf-8
#
# This file is a part of Redmine Helpdesk (redmine_helpdesk) plugin,
# customer support management plugin for Redmine
#
# Copyright (C) 2011-2024 RedmineUP
# http://www.redmineup.com/
#
# redmine_helpdesk is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_helpdesk is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_helpdesk.  If not, see <http://www.gnu.org/licenses/>.

require File.expand_path('../../test_helper', __FILE__)

class HelpdeskDataCollectorFirstResponseTest < ActiveSupport::TestCase
  fixtures :projects,
           :users,
           :roles,
           :members,
           :member_roles,
           :issues,
           :issue_statuses,
           :journals

  RedmineHelpdesk::TestCase.create_fixtures(Redmine::Plugin.find(:redmine_contacts).directory + '/test/fixtures/', [:contacts, :contacts_projects])

  RedmineHelpdesk::TestCase.create_fixtures(Redmine::Plugin.find(:redmine_contacts_helpdesk).directory + '/test/fixtures/', :helpdesk_tickets)

  def test_average_response_time
    responses = Issue.joins(:helpdesk_ticket).where('helpdesk_tickets.first_response_time > 0').pluck(:first_response_time).compact.sort
    middle = responses.count / 2
    average = responses.count.even? ? (responses[middle - 1] + responses[middle]) / 2 : responses[middle]

    assert_equal average.to_i, HelpdeskDataCollectorFirstResponse.new(query_mock).average_response_time
  end

  def test_average_close_time
    resolve_times = Issue.joins(:helpdesk_ticket, :status)
      .where('helpdesk_tickets.first_response_time > 0')
      .where("#{IssueStatus.table_name}.is_closed = ?", true).pluck(:resolve_time).compact.sort
    middle = resolve_times.count / 2
    average = resolve_times.count.even? ? (resolve_times[middle - 1] + resolve_times[middle]) / 2 : resolve_times[middle]

    assert_equal average.to_i, HelpdeskDataCollectorFirstResponse.new(query_mock).average_close_time
  end

  private

  def query_mock
    query = BasicObject.new

    def query.issues
      # In Rails < 4.0 Model.all returns an array rather than relation,
      # but the class under test will try to use 'joins' on it, so in order to
      # support Rails 3 the line below is written this way to return a relation
      # that includes all records.
      Issue.where('created_on IS NOT NULL')
    end

    def query.project; end

    def query.[](_key)
      { 'report_date_period' => { :operator => 'm', :values => [''] } }
    end

    query
  end
end
