require File.expand_path('../../test_helper', __FILE__)

class ReportSchedulesControllerTest < ActionController::TestCase
  include Redmine::I18n

  fixtures :projects, :users, :email_addresses, :user_preferences, :roles, :members, :member_roles,
           :issues, :issue_statuses, :issue_relations, :versions, :trackers, :projects_trackers,
           :issue_categories, :enabled_modules, :enumerations, :attachments, :workflows

  create_fixtures(redmine_reporter_fixtures_directory, [:report_templates, :queries, :report_schedules])

  def setup
    @admin = User.find(1)
    @user = User.find(2)
    @project = Project.find(1)

    @report_schedule_params = {
      project_id: @project.id,
      report_template_id: 6, # TimeEntriesReportTemplate
      query_id: 2,           # TimeEntryQuery
      repeat: ReportSchedule::MONTHLY,
      recipient_ids: [1],
      start_date: '2021-01-01',
      email_subject: 'Test of Report Schedule',
      email_template: 'Public link - {{public_link}}'
    }

    @new_attributes = {
      report_template_id: 6,
      query_id: 2,
      repeat: ReportSchedule::MONTHLY,
      recipient_ids: [1, 2, 3],
      start_date: '2020-06-01',
      end_date: '2020-12-31'
    }
  end

  # === Action :new ===

  def test_should_get_new_for_admin
    @request.session[:user_id] = @admin.id
    compatible_request :get, :new, project_id: @project.identifier
    assert_response :success
  end

  def test_should_get_new_with_permission
    @request.session[:user_id] = @user.id
    Role.find(1).add_permission! :manage_report_templates
    compatible_request :get, :new, project_id: @project.identifier
    assert_response :success
  end

  def test_should_not_access_new_without_permission
    @request.session[:user_id] = @user.id
    compatible_request :get, :new, project_id: @project.identifier
    assert_response :forbidden
  end

  def test_should_not_access_new_for_anonymous
    compatible_request :get, :new, project_id: @project.identifier
    assert_response :redirect
  end

  def test_should_get_new_global_schedule_with_permission
    @request.session[:user_id] = @user.id
    Role.find(1).add_permission! :manage_report_templates
    compatible_request :get, :new
    assert_response :success
  end

  def test_should_switch_query_field
    @request.session[:user_id] = @admin.id
    compatible_request :get, :new
    assert_response :success

    compatible_xhr_request :get, :get_queries, report_template_id: 1
    assert_response :success
    assert_match 'Multiple custom fields query', response.body
  end

  def test_should_have_templates_and_queries_fields
    @request.session[:user_id] = @admin.id
    compatible_request :get, :new
    assert_response :success

    assert_select 'select#report_schedule_report_template_id option[value]' do
      assert_select '[value=?]', '2' # issue template
    end
    assert_select 'select#report_schedule_query_id option[value]' do
      assert_select '[value=?]', '1' # issue query
    end

  end

  # === Action :create ===

  def test_should_create_report_schedule_for_admin
    @request.session[:user_id] = @admin.id
    should_create_report_schedule
  end

  def test_should_create_report_schedule_with_permission
    @request.session[:user_id] = @user.id
    Role.find(1).add_permission! :manage_report_templates
    should_create_report_schedule
  end

  def test_should_not_create_report_schedule_without_permission
    @request.session[:user_id] = @user.id
    should_not_create_report_schedule :forbidden
  end

  def test_should_not_create_report_schedule
    should_not_create_report_schedule
  end

  def test_should_create_global_report_schedule_with_permission
    @request.session[:user_id] = @user.id
    Role.find(1).add_permission! :manage_report_templates
    should_create_report_schedule(@report_schedule_params.merge(project_id: nil), true)
  end

  # === Action :edit ===

  def test_should_get_edit_for_admin
    @request.session[:user_id] = @admin.id
    compatible_request :get, :edit, id: 1
    assert_response :success
  end

  def test_should_get_edit_with_permission
    @request.session[:user_id] = @user.id
    Role.find(1).add_permission! :manage_report_templates
    compatible_request :get, :edit, id: 1
    assert_response :success
  end

  def test_should_not_access_edit_without_permission
    @request.session[:user_id] = @user.id
    compatible_request :get, :edit, id: 1
    assert_response :forbidden
  end

  def test_should_not_access_edit
    compatible_request :get, :edit, id: 1
    assert_response :redirect
  end

  def test_should_get_edit_global_with_permission
    @request.session[:user_id] = @user.id
    Role.find(1).add_permission! :manage_report_templates
    compatible_request :get, :edit, id: 2 # Global schedule
    assert_response :success
  end

  # === Action :update ===

  def test_should_update_report_schedule_for_admin
    @request.session[:user_id] = @admin.id
    should_update_report_schedule(1)
  end

  def test_should_update_report_schedule_with_permission
    @request.session[:user_id] = @user.id
    Role.find(1).add_permission! :manage_report_templates
    should_update_report_schedule(1)
  end

  def test_should_not_update_without_permission
    @request.session[:user_id] = @user.id
    should_not_update_report_schedule 1, @new_attributes, :forbidden
  end

  def test_should_not_update_report_schedule
    should_not_update_report_schedule 1, @new_attributes
  end

  def test_should_not_update_report_schedule_with_invalid_query
    @request.session[:user_id] = @admin.id
    should_not_update_report_schedule 1, { query_id: 2 }, :success
  end

  def test_should_update_global_report_schedule_with_permission
    @request.session[:user_id] = @user.id
    Role.find(1).add_permission! :manage_report_templates
    should_update_report_schedule(2, @new_attributes, true)
  end

  # === Action :destroy ===

  def test_should_destroy_report_schedule_for_admin
    @request.session[:user_id] = @admin.id
    should_destroy_report_schedule(1)
  end

  def test_should_destroy_report_schedule_with_permission
    @request.session[:user_id] = @user.id
    Role.find(1).add_permission! :manage_report_templates
    should_destroy_report_schedule(1)
  end

  def test_should_not_destroy_report_schedule_without_permission
    @request.session[:user_id] = @user.id
    should_not_destroy_report_schedule 1, :forbidden
  end

  def test_should_not_destroy_report_schedule
    should_not_destroy_report_schedule 1
  end

  def test_should_destroy_global_report_schedule_with_permission
    @request.session[:user_id] = @user.id
    Role.find(1).add_permission! :manage_report_templates
    should_destroy_report_schedule(2, true)
  end

  # === Action :autocomplete_for_user ===

  def test_should_get_users_autocomplete_for_admin
    @request.session[:user_id] = @admin.id
    compatible_xhr_request :get, :autocomplete_for_user, project_id: @project.id, q: ''
    assert_response :success
  end

  def test_should_get_users_autocomplete_with_permission
    @request.session[:user_id] = @user.id
    Role.find(1).add_permission! :manage_report_templates
    compatible_xhr_request :get, :autocomplete_for_user, project_id: @project.id, q: ''
    assert_response :success
  end

  def test_should_not_access_users_autocomplete_without_permission
    @request.session[:user_id] = @user.id
    compatible_xhr_request :get, :autocomplete_for_user, project_id: @project.id, q: ''
    assert_response :forbidden
  end

  def test_should_not_access_users_autocomplete_for_anonymous
    compatible_xhr_request :get, :autocomplete_for_user, project_id: @project.id, q: ''
    assert_response :unauthorized
  end

  def test_should_get_users_autocomplete_by_query_string
    @request.session[:user_id] = @admin.id
    compatible_xhr_request :get, :autocomplete_for_user, project_id: @project.id, q: 'john'
    assert_response :success
    users = ActiveSupport::JSON.decode(response.body)
    assert_kind_of Array, users
    assert_equal 1, users.size
    assert_equal 2, users.first['id']
    assert_equal 'John Smith', users.first['text']
  end

  private

  def should_create_report_schedule(params = @report_schedule_params, global = false)
    assert_difference('ReportSchedule.count') do
      compatible_request :post, :create, report_schedule: params
    end
    assert_redirected_to global ? plugin_settings_path('redmine_reporter', tab: 'report_templates') : settings_project_path(@project, tab: 'report_templates')
    assert_equal flash[:notice], l(:notice_successful_create)
  end

  def should_not_create_report_schedule(response_status = :redirect, params = @report_schedule_params)
    assert_difference('ReportSchedule.count', 0) do
      compatible_request :post, :create, report_schedule: params
    end
    assert_response response_status
  end

  def should_update_report_schedule(id, attributes = @new_attributes, global = false)
    compatible_request :post, :update, id: id, report_schedule: attributes
    report_schedule = ReportSchedule.find(id)
    attributes.slice(:report_template_id, :query_id, :repeat)
      .each { |attr, val| assert_equal report_schedule.send(attr), val }

    if attributes[:recipient_ids]
      assert_equal report_schedule.recipient_ids.sort, attributes[:recipient_ids].sort
    end
    if attributes[:start_date]
      assert_equal report_schedule.start_date.to_date.to_s, attributes[:start_date]
    end
    if attributes[:end_date]
      assert_equal report_schedule.end_date.try(:to_date).to_s, attributes[:end_date]
    end

    assert_redirected_to global ? plugin_settings_path('redmine_reporter', tab: 'report_templates') : settings_project_path(@project, tab: 'report_templates')
    assert_equal flash[:notice], l(:notice_successful_update)
  end

  def should_not_update_report_schedule(id, attributes = @new_attributes, response_status = :redirect)
    compatible_request :post, :update, id: id, report_schedule: attributes
    assert_response response_status
    report_schedule = ReportSchedule.find(id)
    attributes.slice(:report_template_id, :query_id, :repeat)
      .each { |attr, val| assert_not_equal report_schedule.send(attr), val }

    if attributes[:recipient_ids]
      assert_not_equal report_schedule.recipient_ids.sort, attributes[:recipient_ids].sort
    end
    if attributes[:start_date]
      assert_not_equal report_schedule.start_date.to_date.to_s, attributes[:start_date]
    end
    if attributes[:end_date]
      assert_not_equal report_schedule.end_date.try(:to_date).to_s, attributes[:end_date]
    end
  end

  def should_destroy_report_schedule(id, global = false)
    assert_difference('ReportSchedule.count', -1) do
      compatible_request :delete, :destroy, id: id
    end
    assert_redirected_to global ? plugin_settings_path('redmine_reporter', tab: 'report_templates') : settings_project_path(@project, tab: 'report_templates')
    assert_equal flash[:notice], l(:notice_successful_delete)
  end

  def should_not_destroy_report_schedule(id, response_status = :redirect)
    assert_difference('ReportSchedule.count', 0) do
      compatible_request :delete, :destroy, id: id
    end
    assert_response response_status
  end
end
