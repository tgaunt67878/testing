require File.expand_path(File.dirname(__FILE__) + '/../../../test/test_helper')

def redmine_reporter_fixtures_directory
  Redmine::Plugin.find(:redmine_reporter).directory + '/test/fixtures/'
end

def redmine_reporter_fixture_files_path
  "#{redmine_reporter_fixtures_directory}files/"
end

def compatible_request(type, action, parameters = {})
  send(type, action, params: parameters)
end

def compatible_xhr_request(type, action, parameters = {})
  send(type, action, params: parameters, xhr: true)
end

def fixtures_class
  ActiveRecord::FixtureSet
end

def create_fixtures(fixtures_directory, table_names, class_names = {})
  fixtures_class.create_fixtures(fixtures_directory, table_names, class_names)
end
