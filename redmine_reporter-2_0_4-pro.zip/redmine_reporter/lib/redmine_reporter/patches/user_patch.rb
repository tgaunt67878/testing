module RedmineReporter
  module Patches
    module UserPatch
      def self.included(base)
        base.class_eval do
          has_and_belongs_to_many :report_schedules
        end
      end
    end
  end
end

unless User.included_modules.include?(RedmineReporter::Patches::UserPatch)
  User.send(:include, RedmineReporter::Patches::UserPatch)
end
