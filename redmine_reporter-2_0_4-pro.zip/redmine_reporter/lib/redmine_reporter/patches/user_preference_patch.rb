module RedmineReporter
  module Patches
    module UserPreferencePatch
      def self.included(base)
        base.class_eval do
          include InstanceMethods

          before_save :clear_unused_block_settings
        end
      end

      module InstanceMethods
        def my_page_layout
          self[:my_page_layout] ||= { 'left' => ['issuesassignedtome'], 'right' => ['issuesreportedbyme'] }
        end

        def my_page_settings(block=nil)
          s = self[:my_page_settings] ||= {}
          if block
            s[block] ||= {}
          else
            s
          end
        end

        def update_block_settings(block, settings)
          block = block.to_s
          block_settings = my_page_settings(block).merge(settings.symbolize_keys)
          my_page_settings[block] = block_settings
        end

        def clear_unused_block_settings
          blocks = my_page_layout.values.flatten
          my_page_settings.keep_if {|block, settings| blocks.include?(block)}
        end
      end
    end
  end
end

unless UserPreference.included_modules.include?(RedmineReporter::Patches::UserPreferencePatch)
  UserPreference.send(:include, RedmineReporter::Patches::UserPreferencePatch)
end
