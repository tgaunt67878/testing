module RedmineReporter
  module Patches
    module ApplicationHelperPatch
      def self.included(base)
        base.class_eval do
          def report_templates_check_box_tags(name, templates)
            return '' if templates.blank?
            s = ''
            templates.each do |template|
              s << "<label>#{check_box_tag name, template.id, false, id: nil} #{h template.name}</label>\n"
            end
            s << javascript_tag('addReportTemplatesCheckboxesListener();')
            s.html_safe
          end

          def schedule_column_content(report_schedule)
            s = l("label_reporter_#{report_schedule.repeat}")
            s << ", #{l(:label_date_from)} #{format_date(report_schedule.start_date)}"
            s << ", #{l(:label_date_to)} #{format_date(report_schedule.end_date)}" if report_schedule.end_date
            s.html_safe
          end

          def recipients_column_content(report_schedule)
            report_schedule
              .recipient_emails
              .sort
              .map { |email| content_tag('div', email) }
              .join
              .html_safe
          end
        end
      end
    end
  end
end

unless ApplicationHelper.included_modules.include?(RedmineReporter::Patches::ApplicationHelperPatch)
  ApplicationHelper.send(:include, RedmineReporter::Patches::ApplicationHelperPatch)
end
