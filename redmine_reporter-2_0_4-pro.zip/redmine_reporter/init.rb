requires_redmineup version_or_higher: '1.0.5' rescue raise "\n\033[31mRedmine requires newer redmineup gem version.\nPlease update with 'bundle update redmineup'.\033[0m"

require 'redmine'

REPORTER_VERSION_NUMBER = '2.0.4'

Redmine::Plugin.register :redmine_reporter do
  name 'Redmine Reporter plugin (PRO version)'
  author 'RedmineUP'
  description 'Printable reports generation for Redmine issues'
  version REPORTER_VERSION_NUMBER
  url 'https://www.redmineup.com/pages/plugins/reporter'
  author_url 'mailto:support@redmineup.com'

  requires_redmine :version_or_higher => '4.0'

  settings default: {}, partial: 'settings/reporter/index'

  project_module :issue_tracking do
    permission :manage_report_templates, {
      report_templates: [:new, :create, :edit, :update, :destroy, :preview, :export, :new_import, :import],
      report_schedules: [:new, :create, :edit, :update, :destroy, :autocomplete_for_user, :test]
    }
    permission :generate_issue_reports, { issues_report_templates: [:new, :create, :autocomplete, :attach]}
    permission :view_issue_reports, { issues_report_templates: [:preview]}
    permission :send_issue_reports, { issue_mails: [:new, :send_mail, :preview] }
  end

  project_module :time_tracking do
    permission :generate_time_entries_reports, { time_entries_reports: [:new, :create, :autocomplete]}
    permission :view_time_entries_reports, { time_entries_reports: [:preview]}
  end
end

if Rails.configuration.respond_to?(:autoloader) && Rails.configuration.autoloader == :zeitwerk
  Rails.autoloaders.each { |loader| loader.ignore(File.dirname(__FILE__) + '/lib') }
end
require File.dirname(__FILE__) + '/lib/redmine_reporter'
