module ReportSchedulesHelper
  def collection_options_for_select(collection, selected)
    options_for_select(collection.map { |x| [x.name, x.id] }, selected)
  end

  def schedule_report_template_select_options(report_schedule)
    collection_options_for_select(report_schedule.allowed_report_templates, report_schedule.report_template_id)
  end

  def schedule_query_select_options(report_schedule)
    collection_options_for_select(report_schedule.allowed_queries, report_schedule.query_id)
  end

  def repeat_options_for_select(selected)
    options_for_select(ReportSchedule::SCHEDULE_REPEATS.map { |x| [l("label_reporter_#{x}"), x] }, selected)
  end
end
