class ReportSchedule < ActiveRecord::Base
  include Redmine::SafeAttributes

  DAILY = 'daily'.freeze
  WEEKLY = 'weekly'.freeze
  MONTHLY = 'monthly'.freeze
  QUARTERLY = 'quarterly'.freeze
  YEARLY = 'yearly'.freeze

  SCHEDULE_REPEATS = [DAILY, WEEKLY, MONTHLY, QUARTERLY, YEARLY].freeze

  safe_attributes 'project_id', 'report_template_id', 'query_id',
                  'repeat','start_date', 'end_date', 'email_subject', 'email_template'

  belongs_to :project, optional: true

  belongs_to :report_template
  belongs_to :query
  has_and_belongs_to_many :recipients, class_name: 'User'

  validates :report_template_id, :query_id, :repeat, :start_date, presence: true
  validates :recipients, presence: true
  validate :check_interval
  validate :validate_repeat_value
  validate :validate_report_template_and_query
  validate :project_id_not_changed, on: :update

  scope :in_project, lambda { |project|
    includes(:report_template, :query, :recipients).where(project: project)
  }

  scope :active, lambda {
    where(<<-SQL.squish, today: Date.today.to_datetime)
      #{table_name}.start_date <= :today AND
        (#{table_name}.end_date IS NULL OR #{table_name}.end_date >= :today)
    SQL
  }

  def self.actual_for_today
    active.select(&:actual?)
  end

  def allowed_report_templates
    @allowed_report_templates ||= ReportTemplate.in_project_and_global(project)
  end

  def allowed_queries
    @allowed_queries ||=
        if [IssueReportTemplate, IssueListReportTemplate].include?(@allowed_report_templates.first.class)
          ::IssueQuery.where(user_id: User.current.id)
        elsif [TimeEntriesReportTemplate].include?(@allowed_report_templates.first.class)
          ::TimeEntryQuery.where(user_id: User.current.id)
        else
          []
        end
  end

  def active?(date = Date.today)
    date >= start_date && (end_date.blank? || date <= end_date)
  end

  def actual?(date = Date.today)
    active?(date) && is_repeat_date?(date)
  end

  def recipient_emails
    recipients.map(&:mail)
  end

  def notified_users
    recipients
  end

  def template_objects
    @template_objects ||= query.is_a?(IssueQuery) ? query.issues : query.results_scope
  end

  def reports
    @reports ||= report_template.generate_reports(template_objects, query_id).flatten
  end

  def public_link_params
    @public_link_params ||= ReportTemplate.public_link_params(template_objects, [report_template], query_id)
  end

  private

  def check_interval
    if start_date && end_date && end_date < start_date
      errors.add(:end_date, :greater_than_or_equal_to_start_date)
    end
  end

  def validate_repeat_value
    errors.add(:repeat, :inclusion) if SCHEDULE_REPEATS.exclude?(repeat)
  end

  def project_id_not_changed
    errors.add(:project, :invalid) if project_id_changed?
  end

  def validate_report_template_and_query
    errors.add(:query, :invalid) if report_template.reported_class != query.queried_class
  end

  def is_monthly_repeat_date?(date = Date.today)
    if date.end_of_month.day < start_date.day
      date == date.end_of_month
    else
      date.day == start_date.day
    end
  end

  def is_repeat_date?(date = Date.today)
    case repeat
    when DAILY
      true
    when WEEKLY
      date.cwday == start_date.to_date.cwday
    when MONTHLY
      is_monthly_repeat_date?(date)
    when QUARTERLY
      date.month % 3 == start_date.month % 3 && is_monthly_repeat_date?(date)
    when YEARLY
      date.month == start_date.month && is_monthly_repeat_date?(date)
    end
  end
end
