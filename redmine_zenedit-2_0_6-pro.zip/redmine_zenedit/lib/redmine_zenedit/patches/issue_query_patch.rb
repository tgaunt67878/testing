# This file is a part of Redmine ZenEdit (redmine_zenedit) plugin,
# editing enhancement plugin for Redmine
#
# Copyright (C) 2011-2024 RedmineUP
# http://www.redmineup.com/
#
# redmine_zenedit is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_zenedit is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_zenedit.  If not, see <http://www.gnu.org/licenses/>.

module RedmineZenedit
  module Patches
    module IssueQueryPatch
      def self.included(base)
        base.send(:include, InstanceMethods)
        base.class_eval do
          alias_method :available_filters_without_viewed_by, :available_filters
          alias_method :available_filters, :available_filters_with_viewed_by
        end
      end

      module InstanceMethods

        def available_filters_with_viewed_by
          if @available_filters.blank?
            add_available_filter(
                "viewed_by_id",
                :name => l(:label_zen_issue_viewed_by),
                :type => :list_optional,
                :values => assigned_to_values
            ) unless available_filters_without_viewed_by.key?('viewed_by_id') && !User.current.allowed_to?(:view_issues, project, :global => true)
          else
            available_filters_without_viewed_by
          end
          @available_filters
        end

        def sql_for_viewed_by_id_field(_field, operator, value)
          me = User.current.id.to_s if value.first == 'me'
          issue_ids = "SELECT DISTINCT(#{Viewing.table_name}.viewed_id) FROM #{Viewing.table_name} WHERE viewed_type = 'Issue' AND viewer_id = #{me || value.first}"

          case operator
          when '='
            "(#{Issue.table_name}.id IN (#{issue_ids}))"
          when '!'
            "(#{Issue.table_name}.id NOT IN (#{issue_ids}))"
          when '*', '!*'
            issue_ids = "SELECT DISTINCT(#{Viewing.table_name}.viewed_id) FROM #{Viewing.table_name} WHERE viewed_type = 'Issue'"
            "(#{Issue.table_name}.id #{'NOT' if operator == '!*'} IN (#{issue_ids}))"
          end
        end

      end
    end
  end
end

if (ActiveRecord::Base.connection.tables.include?('queries') rescue false) &&
    IssueQuery.included_modules.exclude?(RedmineZenedit::Patches::IssueQueryPatch)
  IssueQuery.send(:include, RedmineZenedit::Patches::IssueQueryPatch)
end
