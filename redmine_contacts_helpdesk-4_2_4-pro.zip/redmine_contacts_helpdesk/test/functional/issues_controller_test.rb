# encoding: utf-8
#
# This file is a part of Redmine Helpdesk (redmine_helpdesk) plugin,
# customer support management plugin for Redmine
#
# Copyright (C) 2011-2024 RedmineUP
# http://www.redmineup.com/
#
# redmine_helpdesk is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_helpdesk is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_helpdesk.  If not, see <http://www.gnu.org/licenses/>.

require File.expand_path('../../test_helper', __FILE__)

# Re-raise errors caught by the controller.
# class HelpdeskMailerController; def rescue_action(e) raise e end; end

class IssuesControllerTest < ActionController::TestCase
  fixtures :projects,
           :users,
           :roles,
           :members,
           :member_roles,
           :issues,
           :issue_statuses,
           :versions,
           :trackers,
           :projects_trackers,
           :issue_categories,
           :enabled_modules,
           :enumerations,
           :attachments,
           :workflows,
           :custom_fields,
           :custom_values,
           :custom_fields_projects,
           :custom_fields_trackers,
           :time_entries,
           :journals,
           :journal_details,
           :queries

  RedmineHelpdesk::TestCase.create_fixtures(Redmine::Plugin.find(:redmine_contacts).directory + '/test/fixtures/', [:contacts,
                                                                                                                    :contacts_projects,
                                                                                                                    :deals,
                                                                                                                    :notes,
                                                                                                                    :tags,
                                                                                                                    :taggings,
                                                                                                                    :queries])

  RedmineHelpdesk::TestCase.create_fixtures(Redmine::Plugin.find(:redmine_contacts_helpdesk).directory + '/test/fixtures/', [:journal_messages,
                                                                                                                             :helpdesk_tickets])

  include RedmineHelpdesk::TestHelper

  def setup
    RedmineHelpdesk::TestCase.prepare
    ActionMailer::Base.deliveries.clear
    User.current = nil
  end

  def test_show_issue
    issue = Issue.find(1)
    assert_not_nil issue.helpdesk_ticket
    compatible_request :get, :show, :id => 1
    assert_response :success
  end

  def test_show_reply_to_for_issue_with_ticket
    @request.session[:user_id] = 1
    issue = Issue.find(1)
    assert_not_nil issue.helpdesk_ticket
    compatible_request :get, :show, :id => issue.id
    assert_response :success
    assert_equal response.body.match('Reply').size, 1
  end

  def test_show_reply_to_for_issue_without_ticket
    @request.session[:user_id] = 1
    issue = Issue.find(3)
    assert_nil issue.helpdesk_ticket
    compatible_request :get, :show, :id => issue.id
    assert_response :success
    assert_nil response.body.match('Reply')
  end

  def test_get_index_with_filters
    ticket = HelpdeskTicket.find(1)
    ticket.save

    @request.session[:user_id] = 1
    compatible_request :get, :index, :set_filter => '1', :f => ['ticket_reaction_time', ''], :op => { 'ticket_reaction_time' => '>=' },
                                     :v => { 'ticket_reaction_time' => ['10'] },
                                     :c => ['customer', 'ticket_source', 'customer_company', 'helpdesk_ticket', 'ticket_reaction_time', 'ticket_first_response_time', 'ticket_resolve_time'],
                                     :project_id => 'ecookbook'
    assert_response :success
  end

  def test_get_vote_issues
    ticket = HelpdeskTicket.find(1)
    ticket.update(vote: 1, vote_comment: 'Good!')

    @request.session[:user_id] = 1
    compatible_request :get, :index, :set_filter => '1', :f => ['vote', ''], :op => { 'vote' => '*' }, :c => ['tracker', 'vote', 'vote_comment'],
                                     :project_id => 'ecookbook'
    assert_response :success
    assert_select 'table.list.issues td.vote span', /Just ok/
    assert_select 'table.list.issues td.vote_comment p', /Good/
  end

  def test_get_not_vote_issues
    ticket = HelpdeskTicket.find(1)
    ticket.update(vote: 1, vote_comment: 'Good!')

    @request.session[:user_id] = 1
    compatible_request :get, :index, :set_filter => '1', :f => ['vote', ''], :op => { 'vote' => '!*' }, :c => ['tracker', 'vote', 'vote_comment'],
                                     :project_id => 'ecookbook'
    assert_response :success
    assert_select 'table.list.issues td.vote', ''
  end

  def test_get_only_bad_voted_issues
    ticket = HelpdeskTicket.find(1)
    ticket.update(vote: 1, vote_comment: 'Good!')
    ticket = HelpdeskTicket.find(2)
    ticket.update(vote: 0, vote_comment: 'Bad!')

    @request.session[:user_id] = 1
    compatible_request :get, :index, :set_filter => '1', :f => ['vote', ''], :op => { 'vote' => '=' }, :v => { 'vote' => ['0'] }, :c => ['tracker', 'vote', 'vote_comment'],
                                   :project_id => 'ecookbook'
    assert_response :success
    assert_select 'table.list.issues td.vote span', /Not good/
    assert_select 'table.list.issues td.vote_comment p', /Bad/
    assert_select 'table.list.issues td.vote span' do |votes|
      votes.each do |vote|
        assert_match /^((?!Just ok).)*/, vote.to_s
      end
    end
  end

  def test_get_tickets_as_csv
    with_contacts_settings 'contact_name_format' => :lastname_firstname do
      ticket = HelpdeskTicket.find(1)
      ticket.update(vote: 1, vote_comment: 'Good!')
      ticket = HelpdeskTicket.find(2)
      ticket.update(vote: 0, vote_comment: 'Bad!')

      @request.session[:user_id] = 1
      compatible_request :get, :index, :set_filter => '1', :f => ['vote', ''], :op => { 'vote' => '=' }, :v => { 'vote' => ['1', '0'] },
                                       :c => ['tracker', 'vote', 'vote_comment', 'last_message', 'last_message_date', 'customer', 'ticket_source', 'customer_company', 'helpdesk_ticket_relation', 'ticket_reaction_time', 'ticket_first_response_time', 'ticket_resolve_time'],
                                       :project_id => 'ecookbook',
                                       :format => 'csv'
      assert_response :success
      assert_not_nil issues_in_list
      assert_match 'text/csv', @response.content_type
      assert @response.body.starts_with?('#,')
      assert @response.body.include?('Ticket: ')
      assert @response.body.include?('Marat Aminov')
    end
  end

  def test_get_tickets_as_pdf
    ticket = HelpdeskTicket.find(1)
    ticket.update(vote: 1, vote_comment: 'Good!')
    ticket = HelpdeskTicket.find(2)
    ticket.update(vote: 0, vote_comment: 'Bad!')

    @request.session[:user_id] = 1
    compatible_request :get, :index, :set_filter => '1', :f => ['vote', ''], :op => { 'vote' => '=' }, :v => { 'vote' => ['1', '0'] },
                                     :c => ['tracker', 'vote', 'vote_comment', 'last_message', 'last_message_date', 'customer', 'ticket_source', 'customer_company', 'helpdesk_ticket_relation', 'ticket_reaction_time', 'ticket_first_response_time', 'ticket_resolve_time'],
                                     :project_id => 'ecookbook',
                                     :format => 'pdf'
    assert_response :success
    assert_not_nil issues_in_list
    assert_equal 'application/pdf', @response.content_type
    assert @response.body.starts_with?('%PDF')
  end

  def test_should_send_note
    user = User.find(1)
    @request.session[:user_id] = 1
    notes = "Hello, %%NAME%%\r\n Bye, %%NOTE_AUTHOR.FIRST_NAME%%"
    # anonymous user
    compatible_request :put, :update, :id => 1, :helpdesk => { :is_send_mail => 1 }, :issue => { :notes => notes }
    assert_redirected_to :action => 'show', :id => '1'
    j = Journal.order('id DESC').first
    assert_equal "Hello, Ivan\r\n Bye, #{user.firstname}", j.notes
    assert_equal 0, j.details.size
    assert_equal User.find(1), j.user

    mail = last_ticket_mail
    assert_mail_body_match "Hello, Ivan\r\n Bye, #{user.firstname}", mail
    assert_equal Issue.find(1).customer.primary_email, mail.to.first
  end

  def test_should_not_send_note_with_zero_param
    user = User.find(1)
    @request.session[:user_id] = 1
    notes = "Not send"
    # anonymous user
    compatible_request :put, :update, :id => 1, :helpdesk => { :is_send_mail => 0 }, :issue => { :notes => notes }
    assert_redirected_to :action => 'show', :id => '1'

    j = Journal.order('id DESC').first
    assert_equal "Not send", j.notes
    assert_equal true, j.is_send_note.nil?
    assert_equal User.find(1), j.user

    assert last_ticket_mail.nil?
  end

  def test_should_calculate_metrics
    @request.session[:user_id] = 1

    issue = Issue.find(1)
    issue.journals.destroy_all

    compatible_request :put, :update, :id => 1, :helpdesk => { :is_send_mail => 1 }, :issue => { :notes => 'Response to customer' }

    issue.reload
    assert_not_nil issue.helpdesk_ticket.first_response_time
    assert_equal (issue.helpdesk_ticket.reaction_time - issue.helpdesk_ticket.first_response_time) < 100, true
  end

  def test_should_forward_note
    user = User.find(1)
    @request.session[:user_id] = 1
    notes = "Hello, %%NAME%%\r\n Bye, %%NOTE_AUTHOR.FIRST_NAME%%"
    # anonymous user
    compatible_request :put, :update, :id => 1, :helpdesk => { :is_send_mail => 1 },
                                      :journal_message => { :to_address => ['jsmith@somenet.foo'] }, :issue => { :notes => notes }
    assert_redirected_to :action => 'show', :id => '1'
    j = Journal.order('id DESC').first
    assert_match "Hello, Ivan\r\n Bye, #{user.firstname}", j.notes
    assert_equal 0, j.details.size
    assert_equal User.find(1), j.user
    assert_equal Contact.find(4), j.journal_message.contact

    mail = last_ticket_mail
    assert_mail_body_match "Hello, Ivan\r\n Bye, #{user.firstname}", mail
    assert_equal 'jsmith@somenet.foo', mail.to.first
  end

  def test_should_send_note_with_bcc
    issue = Issue.find(1)
    contact = Contact.find(1)
    user = User.find(1)
    issue.helpdesk_ticket = HelpdeskTicket.new(:customer => contact,
                                               :issue => issue,
                                               :from_address => contact.primary_email,
                                               :ticket_date => Time.now)
    issue.save!

    @request.session[:user_id] = 1
    notes = "Hello, %%NAME%%\r\n Bye, %%NOTE_AUTHOR.FIRST_NAME%%"
    # anonymous user
    compatible_request :put, :update, :id => 1, :helpdesk => { :is_send_mail => 1 }, :journal_message => { :bcc_address => ['mail1@mail.com', 'mail2@mail.com'] },
                                      :issue => { :notes => notes }
    assert_redirected_to :action => 'show', :id => '1'
    j = Journal.order('id DESC').first
    assert_equal "Hello, Ivan\r\n Bye, #{user.firstname}", j.notes
    assert_equal 0, j.details.size
    assert_equal User.find(1), j.user

    mail = last_ticket_mail
    assert_mail_body_match "Hello, Ivan\r\n Bye, #{user.firstname}", mail
    assert_equal Issue.find(1).customer.primary_email, mail.to.first
    assert_equal ['mail1@mail.com', 'mail2@mail.com'].sort, mail.bcc.sort
  end

  def test_should_not_send_note_with_cc
    issue = Issue.find(1)
    contact = Contact.find(1)
    user = User.find(1)
    issue.helpdesk_ticket = HelpdeskTicket.new(:customer => contact,
                                               :issue => issue,
                                               :from_address => contact.primary_email,
                                               :ticket_date => Time.now)
    issue.save!

    @request.session[:user_id] = 1
    notes = "Hello, %%NAME%%\r\n Bye, %%NOTE_AUTHOR.FIRST_NAME%%"
    # anonymous user
    compatible_request :put, :update, :id => 1, :helpdesk => { :is_send_mail => 1 }, :journal_message => { :cc_address => ['mail3@mail.com', 'mail4@mail.com'] },
                                      :issue => { :notes => notes }
    assert_redirected_to :action => 'show', :id => '1'
    j = Journal.order('id DESC').first
    assert_equal "Hello, Ivan\r\n Bye, #{user.firstname}", j.notes
    assert_equal 0, j.details.size
    assert_equal User.find(1), j.user

    mail = last_ticket_mail
    assert_mail_body_match "Hello, Ivan\r\n Bye, #{user.firstname}", mail
    assert_equal Issue.find(1).customer.primary_email, mail.to.first
    assert_equal ['mail3@mail.com', 'mail4@mail.com'].sort, mail.cc.sort
    assert mail.bcc.empty?, 'Bcc should be empty'
  end

  def test_should_send_note_with_attachments
    issue = Issue.find(1)
    contact = Contact.find(1)
    user = User.find(1)
    issue.helpdesk_ticket = HelpdeskTicket.new(:customer => contact,
                                               :issue => issue,
                                               :from_address => contact.primary_email,
                                               :ticket_date => Time.now)
    issue.save!

    @request.session[:user_id] = user.id
    notes = "Hello, %%NAME%%\r\n Bye, %%NOTE_AUTHOR.FIRST_NAME%%"
    # anonymous user
    compatible_request :put, :update, :id => 1, :helpdesk => { :is_send_mail => 1 }, :issue => { :notes => notes },
                                      :attachments => { '1' => { 'file' => helpdesk_uploaded_file('attachment.zip', 'application/octet-stream') } }
    mail = last_ticket_mail
    assert_not_nil mail.attachments
    assert_equal 3855, mail.attachments.first.decoded.size
  end

  def test_should_send_private_note_with_attachments
    issue = Issue.find(1)
    contact = Contact.find(1)
    user = User.find(1)
    issue.helpdesk_ticket = HelpdeskTicket.new(:customer => contact,
                                               :issue => issue,
                                               :from_address => contact.primary_email,
                                               :ticket_date => Time.now)
    issue.save!

    @request.session[:user_id] = user.id
    notes = "Hello, %%NAME%%\r\n Bye, %%NOTE_AUTHOR.FIRST_NAME%%"
    # anonymous user
    compatible_request :put, :update, :id => 1, :helpdesk => { :is_send_mail => 1 }, :issue => { :notes => notes, :private_notes => 1 },
                                      :attachments => { '1' => { 'file' => helpdesk_uploaded_file('attachment.zip', 'application/octet-stream') } }
    assert_equal issue.reload.journals.last.private_notes, true
    mail = last_ticket_mail
    assert_not_nil mail.attachments
    assert_equal 3855, mail.attachments.first.decoded.size
  end

  def test_should_send_note_issue_from_anonymous
    issue = Issue.find(1)
    issue.author_id = 6
    contact = Contact.find(1)
    user = User.find(1)
    issue.helpdesk_ticket = HelpdeskTicket.new(:customer => contact,
                                               :issue => issue,
                                               :from_address => contact.primary_email,
                                               :ticket_date => Time.now)
    issue.save!

    @request.session[:user_id] = 1
    notes = "Hello, %%NAME%%\r\n Bye, %%NOTE_AUTHOR.FIRST_NAME%%"
    # anonymous user
    compatible_request :put, :update, :id => 1, :helpdesk => { :is_send_mail => 1 }, :issue => { :notes => notes }
    assert_redirected_to :action => 'show', :id => '1'
    j = Journal.order('id DESC').first
    assert_equal "Hello, Ivan\r\n Bye, #{user.firstname}", j.notes
    assert_equal 0, j.details.size
    assert_equal User.find(1), j.user

    mail = last_ticket_mail
    assert_mail_body_match "Hello, Ivan\r\n Bye, #{user.firstname}", mail
    assert_equal Issue.find(1).customer.primary_email, mail.to.first
  end

  def test_should_create_ticket
    @request.session[:user_id] = 1
    project = Project.find('ecookbook')
    contact = Contact.find(2)
    assert_difference 'HelpdeskTicket.count' do
      compatible_request :post, :create, issue: { tracker_id: 3, subject: 'test', status_id: 2, priority_id: 5,
                                                  helpdesk_ticket_attributes: { source: '0', ticket_date: '2013-01-01 01:01:01 +0400', contact_id: contact.id } },
                                         project_id: project
    end
    assert_redirected_to controller: 'issues', action: 'show', id: Issue.last.id
    assert_not_nil Issue.last.helpdesk_ticket
    assert_equal contact.emails.first, Issue.last.helpdesk_ticket.from_address
  end

  def test_should_create_ticket_for_non_primary_email
    @request.session[:user_id] = 1
    project = Project.find('ecookbook')
    contact = Contact.find(2)
    assert_difference 'HelpdeskTicket.count' do
      compatible_request :post, :create, issue: { tracker_id: 3, subject: 'test', status_id: 2, priority_id: 5,
                                                  helpdesk_ticket_attributes: { source: '0', ticket_date: '2013-01-01 01:01:01 +0400' } },
                                         customer_address: contact.emails.last,
                                         project_id: project
    end
    assert_redirected_to controller: 'issues', action: 'show', id: Issue.last.id
    assert_not_nil Issue.last.helpdesk_ticket
    assert_not_equal contact.emails.last, contact.primary_email
    assert_equal contact.emails.last, Issue.last.helpdesk_ticket.from_address
  end

  def test_should_send_auto_answer
    @request.session[:user_id] = 1
    contact = Contact.find(1)
    cc_addresses = 'test1@mail.com, test2@mail.com'
    bcc_addresses = 'test3@mail.com, test4@mail.com'
    assert_difference 'HelpdeskTicket.count' do
      compatible_request :post, :create, issue: { tracker_id: 3, subject: 'test', status_id: 2, priority_id: 5, description: 'test description',
                                                  helpdesk_ticket_attributes: { source: '0', ticket_date: '2013-01-01 01:01:01 +0400', contact_id: contact.id } },
                                         helpdesk_send_as: HelpdeskTicket::SEND_AS_NOTIFICATION,
                                         project_id: 1,
                         cc_addresses: cc_addresses,
                         bcc_addresses: bcc_addresses
    end
    mail = last_ticket_mail
    assert_mail_body_match 'We hereby confirm that we have received your message', mail
    assert_equal cc_addresses, mail.cc.join(', ')
    assert_equal bcc_addresses, mail.bcc.join(', ')
  end

  def test_should_send_initial_message
    with_helpdesk_settings('helpdesk_first_answer_subject' => 'Message for ticket id: #{%ticket.id%}') do
      @request.session[:user_id] = 1
      contact = Contact.find(1)
      cc_addresses = 'test1@mail.com, test2@mail.com'
      bcc_addresses = 'test3@mail.com, test4@mail.com'
      assert_difference 'HelpdeskTicket.count' do
        compatible_request :post, :create, issue: { tracker_id: 3, subject: 'test', status_id: 2, priority_id: 5, description: 'test initial description',
                                                    helpdesk_ticket_attributes: { source: '0', ticket_date: '2013-01-01 01:01:01 +0400', contact_id: contact.id } },
                                           helpdesk_send_as: HelpdeskTicket::SEND_AS_MESSAGE,
                                           project_id: 1,
                           cc_addresses: cc_addresses,
                           bcc_addresses: bcc_addresses
      end
      mail = last_ticket_mail
      assert_mail_body_match 'test initial description', mail
      assert_equal mail.subject, "Message for ticket id: \##{Issue.maximum(:id)}"
      assert_equal HelpdeskTicket.order('id ASC').last.message_id, mail.message_id
      assert_equal false, HelpdeskTicket.order('id ASC').last.is_incoming
      assert_equal cc_addresses, mail.cc.join(', ')
      assert_equal bcc_addresses, mail.bcc.join(', ')
    end
  end

  def test_should_send_initial_message_to_second_email
    @request.session[:user_id] = 1
    contact = Contact.find(1)
    contact.update(email: contact.email + ',second@email.com')
    assert_difference 'HelpdeskTicket.count' do
      compatible_request :post, :create, issue: { tracker_id: 3, subject: 'test', status_id: 2, priority_id: 5, description: 'test initial description',
                                                  helpdesk_ticket_attributes: { source: '0', ticket_date: '2013-01-01 01:01:01 +0400', contact_id: contact.id } },
                                         helpdesk_send_as: HelpdeskTicket::SEND_AS_MESSAGE,
                                         customer_address: contact.emails.last,
                                         project_id: 1
    end
    mail = last_ticket_mail
    assert_mail_body_match 'test initial description', mail
    assert_equal HelpdeskTicket.order('id ASC').last.message_id, mail.message_id
    assert_equal ['second@email.com'], mail.to
  end

  def test_should_not_create_ticket_for_invalid_issue
    @request.session[:user_id] = 1
    ActionMailer::Base.deliveries.clear
    compatible_request :put, :update, id: 1, helpdesk: { is_send_mail: 1 }, issue: { notes: 'Test notes', subject: '' }
    assert_equal ActionMailer::Base.deliveries, []
  end

  def test_should_not_create_ticket_with_empty_customer
    @request.session[:user_id] = 1
    project = Project.find('ecookbook')
    assert_no_difference 'HelpdeskTicket.count' do
      compatible_request :post, :create, issue: { tracker_id: 3, subject: 'Test subject', status_id: 2, priority_id: 5,
                                                  helpdesk_ticket_attributes: { source: '0', ticket_date: '2013-01-01 01:01:01 +0400' } },
                                         project_id: project
      assert_select 'div#errorExplanation', /customer cannot be blank/i
    end
  end

  def test_should_set_from_field_for_ticket
    @request.session[:user_id] = 1
    project = Project.find('ecookbook')
    contact = Contact.find(1)
    assert_difference 'HelpdeskTicket.count' do
      compatible_request :post, :create, issue: { tracker_id: 3, subject: 'test_for_field', status_id: 2, priority_id: 5,
                                                  helpdesk_ticket_attributes: { contact_id: contact.id, source: '0', ticket_date: '2013-01-01 01:01:01 +0400' } },
                                         project_id: project
    end
    assert_not_nil Issue.last.helpdesk_ticket
    assert_equal Issue.last.helpdesk_ticket.from_address, contact.primary_email
  end

  def test_should_send_note_without_to
    issue = Issue.find(1)
    contact = Contact.find(1)
    user = User.find(1)
    issue.helpdesk_ticket = HelpdeskTicket.new(:customer => contact,
                                               :issue => issue,
                                               :from_address => contact.primary_email,
                                               :ticket_date => Time.now)
    issue.save!

    @request.session[:user_id] = 1
    notes = "Empty to-address"

    compatible_request :put, :update, id: 1, helpdesk: { is_send_mail: 1 }, journal_message: { to_address: [''],
                                                                                               cc_address: ['cc@mail.com'],
                                                                                               bcc_address: ['bcc@mail.com'] },
                                             issue: { notes: notes }
    mail = last_ticket_mail
    assert_mail_body_match "Empty to-address", mail
    assert_nil mail.to.first
    assert_equal ['cc@mail.com'], mail.cc
    assert_equal ['bcc@mail.com'], mail.bcc
  end

  def test_should_build_new_ticket_for_customer
    @request.session[:user_id] = 1
    contact = Contact.find(1)
    tracker = Tracker.find(1)
    project = Project.find('ecookbook')
    compatible_request :get, :new, project_id: project.id, customer_id: contact.id, tracker_id: tracker.id

    assert_response :success
    assert_match 'New issue', @response.body
  end

  def test_should_build_new_ticket_for_customer_without_tracket_attr
    @request.session[:user_id] = 1
    contact = Contact.find(1)
    tracker = Tracker.find(1)
    project = Project.find('ecookbook')
    compatible_request :get, :new, project_id: project.id, customer_id: contact.id

    assert_response :success
    assert_match 'New issue', @response.body
  end

  def test_should_create_contact_on_reply
    @request.session[:user_id] = 1
    notes = "Notes to another contact"
    compatible_request :put, :update, id: 1, helpdesk: { is_send_mail: 1 },
                                             journal_message: { to_address: ['not_exists@email.com'] },
                                             issue: { notes: notes }
    assert_redirected_to action: 'show', id: '1'
    last_journal = Journal.order('id DESC').first
    last_contact = Contact.order('id DESC').first
    assert_equal notes, last_journal.notes
    assert_equal last_contact, last_journal.contact
    assert_equal 'not_exists@email.com', last_contact.email

    mail = last_ticket_mail
    assert_mail_body_match notes, mail
    assert_equal 'not_exists@email.com', mail.to.first
  end

  def test_should_use_global_CC_BCC_for_initial_message
    with_helpdesk_settings('helpdesk_cc_address' => 'cc@email.com', 'helpdesk_bcc_address' => 'bcc@email.com') do
      @request.session[:user_id] = 1
      contact = Contact.find(1)
      assert_difference 'HelpdeskTicket.count' do
        compatible_request :post, :create, issue: { tracker_id: 3, subject: 'test', status_id: 2, priority_id: 5, description: 'test initial description',
                                                    helpdesk_ticket_attributes: { source: '0', ticket_date: '2013-01-01 01:01:01 +0400', contact_id: contact.id } },
                                           helpdesk_send_as: HelpdeskTicket::SEND_AS_MESSAGE,
                                           project_id: 1
      end
      mail = last_ticket_mail
      assert_mail_body_match 'test initial description', mail
      assert_equal ['cc@email.com'], mail.cc
      assert_equal ['bcc@email.com'], mail.bcc
    end
  end

  def test_should_use_global_CC_BCC_for_initial_message
    project = Project.find(1)
    with_helpdesk_settings('helpdesk_cc_address' => 'cc@email.com', 'helpdesk_bcc_address' => 'bcc@email.com') do
      @request.session[:user_id] = 1
      contact = Contact.find(1)
      assert_difference 'HelpdeskTicket.count' do
        compatible_request :post, :create, issue: { subject: 'test', description: 'Global CC, Global BCC',
                                                    helpdesk_ticket_attributes: { contact_id: contact.id } },
                                          helpdesk_send_as: HelpdeskTicket::SEND_AS_MESSAGE,
                                          project_id: project.id
      end
      mail = last_ticket_mail
      assert_mail_body_match 'Global CC, Global BCC', mail
      assert_equal ['cc@email.com'], mail.cc
      assert_equal ['bcc@email.com'], mail.bcc
    end
  end

  def test_should_prefer_project_CC_BCC_for_initial_message
    project = Project.find(2)
    with_helpdesk_settings('helpdesk_cc_address' => 'cc@email.com', 'helpdesk_bcc_address' => 'bcc@email.com') do
      with_helpdesk_project_settings(project, 'helpdesk_cc_address' => 'project_cc@email.com', 'helpdesk_bcc_address' => 'project_bcc@email.com') do
        @request.session[:user_id] = 1
        contact = Contact.find(1)
        assert_difference 'HelpdeskTicket.count' do
          compatible_request :post, :create, issue: { subject: 'test', description: 'Project CC, Project BCC',
                                                      helpdesk_ticket_attributes: { contact_id: contact.id } },
                                            helpdesk_send_as: HelpdeskTicket::SEND_AS_MESSAGE,
                                            project_id: project.id
        end
        mail = last_ticket_mail
        assert_mail_body_match 'Project CC, Project BCC', mail
        assert_equal ['project_cc@email.com'], mail.cc
        assert_equal ['project_bcc@email.com'], mail.bcc
      end
    end
  end

  def test_should_mix_CC_BCC_settings_for_initial_message
    project = Project.find(3)
    with_helpdesk_settings('helpdesk_cc_address' => 'cc@email.com') do
      with_helpdesk_project_settings(project, 'helpdesk_bcc_address' => 'project_bcc@email.com') do
        @request.session[:user_id] = 1
        contact = Contact.find(1)
        assert_difference 'HelpdeskTicket.count' do
          compatible_request :post, :create, issue: { subject: 'test', description: 'Global CC, Project BCC',
                                                      helpdesk_ticket_attributes: { contact_id: contact.id } },
                                            helpdesk_send_as: HelpdeskTicket::SEND_AS_MESSAGE,
                                            project_id: project.id
        end
        mail = last_ticket_mail
        assert_mail_body_match 'Global CC, Project BCC', mail
        assert_equal ['cc@email.com'], mail.cc
        assert_equal ['project_bcc@email.com'], mail.bcc
      end
    end
  end

  def test_should_use_global_CC_BCC_for_autoanswer_message
    project = Project.find(1)
    with_helpdesk_settings('helpdesk_cc_address' => 'cc@email.com', 'helpdesk_bcc_address' => 'bcc@email.com') do
      @request.session[:user_id] = 1
      contact = Contact.find(1)
      assert_difference 'HelpdeskTicket.count' do
        compatible_request :post, :create, issue: { subject: 'test', description: 'Global CC, Global BCC',
                                                    helpdesk_ticket_attributes: { contact_id: contact.id } },
                                          helpdesk_send_as: HelpdeskTicket::SEND_AS_NOTIFICATION,
                                          project_id: project.id
      end
      mail = last_ticket_mail
      assert_equal ['cc@email.com'], mail.cc
      assert_equal ['bcc@email.com'], mail.bcc
    end
  end

  def test_should_prefer_project_CC_BCC_for_autoanswer_message
    project = Project.find(2)
    with_helpdesk_settings('helpdesk_cc_address' => 'cc@email.com', 'helpdesk_bcc_address' => 'bcc@email.com') do
      with_helpdesk_project_settings(project, 'helpdesk_cc_address' => 'project_cc@email.com', 'helpdesk_bcc_address' => 'project_bcc@email.com') do
        @request.session[:user_id] = 1
        contact = Contact.find(1)
        assert_difference 'HelpdeskTicket.count' do
          compatible_request :post, :create, issue: { subject: 'test', description: 'Project CC, Project BCC',
                                                      helpdesk_ticket_attributes: { contact_id: contact.id } },
                                            helpdesk_send_as: HelpdeskTicket::SEND_AS_NOTIFICATION,
                                            project_id: project.id
        end
        mail = last_ticket_mail
        assert_equal ['project_cc@email.com'], mail.cc
        assert_equal ['project_bcc@email.com'], mail.bcc
      end
    end
  end

  def test_should_mix_CC_BCC_settings_for_autoanswer_message
    project = Project.find(3)
    with_helpdesk_settings('helpdesk_cc_address' => 'cc@email.com') do
      with_helpdesk_project_settings(project, 'helpdesk_bcc_address' => 'project_bcc@email.com') do
        @request.session[:user_id] = 1
        contact = Contact.find(1)
        assert_difference 'HelpdeskTicket.count' do
          compatible_request :post, :create, issue: { subject: 'test', description: 'Global CC, Project BCC',
                                                      helpdesk_ticket_attributes: { contact_id: contact.id } },
                                            helpdesk_send_as: HelpdeskTicket::SEND_AS_NOTIFICATION,
                                            project_id: 3
        end
        mail = last_ticket_mail
        assert_equal ['cc@email.com'], mail.cc
        assert_equal ['project_bcc@email.com'], mail.bcc
      end
    end
  end

  def test_should_create_ticket_for_private_issues
    with_helpdesk_settings('helpdesk_create_private_tickets' => '1', 'helpdesk_assign_contact_user' => '1') do
      @request.session[:user_id] = 1
      project = Project.find('ecookbook')
      contact = Contact.find(2)
      assert_difference 'HelpdeskTicket.count' do
        compatible_request :post, :create, issue: { tracker_id: 3, subject: 'test', status_id: 2, priority_id: 5,
                                                    helpdesk_ticket_attributes: { source: '0', ticket_date: '2013-01-01 01:01:01 +0400', contact_id: contact.id } },
                                          project_id: project
      end
      assert_redirected_to controller: 'issues', action: 'show', id: Issue.last.id
      assert_not_nil Issue.last.helpdesk_ticket
      assert_equal Issue.last.is_private, true
      assert_equal contact.emails.first, Issue.last.helpdesk_ticket.from_address
    end
  end

  def test_should_add_cc_addresses_from_ticket
    issue = Issue.find(1)
    contact = Contact.find(1)
    user = User.find(1)

    @request.session[:user_id] = 1
    compatible_request :get, :show, id: issue.id
    assert_response :success

    assert_match 'copy1@email.com', @response.body
    assert_match 'copy2@email.com', @response.body
  end

  def test_should_open_new_issue_with_default_project_with_enabled_helpdesk_form
    @request.session[:user_id] = 1
    project = Project.find(1)
    with_helpdesk_project_settings(project, 'helpdesk_tracker' => 'all') do
      compatible_request :get, :new

      assert_response :success
      assert_match 'New issue', @response.body
    end
  end

  private

  def last_ticket_mail
    ActionMailer::Base.deliveries.detect { |m| m['X-Redmine-Ticket-ID'] }
  end

end
