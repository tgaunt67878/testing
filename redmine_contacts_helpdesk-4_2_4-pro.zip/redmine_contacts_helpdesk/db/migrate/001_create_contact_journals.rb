# This file is a part of Redmine Helpdesk (redmine_helpdesk) plugin,
# customer support management plugin for Redmine
#
# Copyright (C) 2011-2024 RedmineUP
# http://www.redmineup.com/
#
# redmine_helpdesk is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_helpdesk is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_helpdesk.  If not, see <http://www.gnu.org/licenses/>.

class CreateContactJournals < ActiveRecord::Migration[4.2]
  def self.up
    create_table :contact_journals do |t|
      t.references :contact
      t.references :journal
      t.string :email
      t.boolean :is_incoming
      t.timestamps :null => false
    end
    add_index :contact_journals, [:journal_id, :contact_id]
  end

  def self.down
    drop_table :contact_journals
  end
end

