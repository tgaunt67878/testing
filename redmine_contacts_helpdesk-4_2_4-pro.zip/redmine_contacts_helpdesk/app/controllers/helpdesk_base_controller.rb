# This file is a part of Redmine Helpdesk (redmine_helpdesk) plugin,
# customer support management plugin for Redmine
#
# Copyright (C) 2011-2024 RedmineUP
# http://www.redmineup.com/
#
# redmine_helpdesk is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_helpdesk is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_helpdesk.  If not, see <http://www.gnu.org/licenses/>.

class HelpdeskBaseController < ApplicationController

  def process_helpdesk_send_as(send_as = nil)
    return unless @issue && User.current.allowed_to?(:send_response, @project)
    return unless send_as

    case send_as
    when 'auto_answer'
      HelpdeskMailer.auto_answer(@issue.customer, @issue)
    when 'initial_message'
      if msg = HelpdeskMailer.initial_message(@issue.customer, @issue)
        @issue.helpdesk_ticket.message_id = msg.message_id
        @issue.helpdesk_ticket.is_incoming = false
        @issue.helpdesk_ticket.from_address = @issue.helpdesk_ticket.from_address || @issue.customer.primary_email
        @issue.helpdesk_ticket.save
      end
    else
      HelpdeskMailer.auto_answer(@contact, @issue) if HelpdeskSettings['helpdesk_send_notification', @project].to_i > 0
    end
  end
end
