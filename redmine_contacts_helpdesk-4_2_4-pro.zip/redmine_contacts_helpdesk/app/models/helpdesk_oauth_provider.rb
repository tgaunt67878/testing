# This file is a part of Redmine Helpdesk (redmine_helpdesk) plugin,
# customer support management plugin for Redmine
#
# Copyright (C) 2011-2024 RedmineUP
# http://www.redmineup.com/
#
# redmine_helpdesk is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_helpdesk is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_helpdesk.  If not, see <http://www.gnu.org/licenses/>.

class HelpdeskOauthProvider
  class SendMailError < StandardError; end

  PROVIDERS = {
    outlook: HelpdeskOauthProvider::Microsoft,
    google: HelpdeskOauthProvider::Google
  }.freeze
  attr_accessor :project, :redirect_uri

  def self.find_by_protocol(protocol)
    PROVIDERS[protocol&.to_sym]
  end

  def initialize(project_id)
    @project = Project.find(project_id)
    @redirect_uri = Rails.application.routes.url_helpers.helpdesk_oauth_resp_url(protocol: Setting.protocol, host: Setting.host_name)
  end

  def reset_token
    write_tokens(nil, nil)
  end

  private

  def logger
    HelpdeskLogger
  end

  def logged_error(message = nil)
    logger.error(message) if message
    false
  end

  def access_token_name
    raise NoMethodError, 'Should be implemented in a subclass'
  end

  def refresh_token_name
    raise NoMethodError, 'Should be implemented in a subclass'
  end

  def update_token
    raise NoMethodError, 'Should be implemented in a subclass'
  end

  def write_tokens(access, refresh)
    ContactsSetting[access_token_name, project.id] = access
    ContactsSetting[refresh_token_name, project.id] = refresh
  end

  def is_ok?(code)
    [200, 202].include?(code.to_i)
  end

  def execute(type, url, params = {})
    uri = URI(url)
    req = send("build_#{type.downcase}_req", url, params) if [:GET, :FPOST, :JPOST, :TPOST, :PATCH, :RFPOST].include?(type)
    raise 'Incorrect request type' unless req

    req['Authorization'] = "Bearer #{HelpdeskSettings[access_token_name, project]}"
    resp = Net::HTTP.start(uri.hostname, uri.port, use_ssl: uri.scheme == 'https') do |conn|
      conn.request(req)
    end

    code, data = execute_with_reloaded_token(type, url, params) if resp.is_a?(Net::HTTPUnauthorized) && !params[:reloaded]
    [(code || resp.code).to_i, data || (params[:raw] ? resp.body : JSON.parse(resp.body))]
  end

  def execute_with_reloaded_token(type, url, params)
    update_token
    execute(type, url, params.merge(reloaded: true))
  end

  def build_get_req(url, params)
    get_url = url
    if params&.any?
      quoted_params = params.to_query
      quoted_params = quoted_params.gsub('labelIds%5B%5D', 'labelIds') if params[:g_labels]
      get_url = get_url + '?' + quoted_params
    end
    Net::HTTP::Get.new(get_url)
  end

  def build_fpost_req(url, params)
    post_req = Net::HTTP::Post.new(url)
    post_req.set_form_data(params) if params
    post_req
  end

  def build_jpost_req(url, params)
    post_req = Net::HTTP::Post.new(url)
    post_req.content_type = "application/json"
    post_req.body = JSON.dump(params) if params
    post_req
  end

  def build_rfpost_req(url, params)
    post_req = Net::HTTP::Post.new(url)
    post_req.content_type = "message/rfc822"
    post_req.body = JSON.dump(params) if params
    post_req
  end

  def build_tpost_req(url, params)
    post_req = Net::HTTP::Post.new(url)
    post_req.content_type = "text/plain"
    post_req.body = params[:body] if params
    post_req
  end

  def build_patch_req(url, params)
    patch_req = Net::HTTP::Patch.new(url)
    patch_req.content_type = "application/json"
    patch_req.body = JSON.dump(params) if params
    patch_req
  end
end
