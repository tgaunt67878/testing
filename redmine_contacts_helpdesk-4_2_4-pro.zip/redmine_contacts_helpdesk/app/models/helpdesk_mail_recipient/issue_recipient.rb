# This file is a part of Redmine Helpdesk (redmine_helpdesk) plugin,
# customer support management plugin for Redmine
#
# Copyright (C) 2011-2024 RedmineUP
# http://www.redmineup.com/
#
# redmine_helpdesk is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_helpdesk is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_helpdesk.  If not, see <http://www.gnu.org/licenses/>.

class HelpdeskMailRecipient::IssueRecipient < HelpdeskMailRecipient
  def receive
    issue = Issue.new(author: container.from_user, project: project)
    issue.tracker_id = tracker_id(issue)

    issue.safe_attributes = helpdesk_issue_attributes(issue)
    issue.safe_attributes = { 'custom_field_values' => helpdesk_custom_field_values(issue) }
    issue.subject = cleaned_up_subject(email)
    issue.subject = '(no subject)' if issue.subject.blank?
    issue.description = container.text_body
    issue.start_date ||= Date.today if Setting.default_issue_start_date_to_creation_date?
    issue.assigned_to = contact.find_assigned_user(project, issue.assigned_to_id || HelpdeskSettings['helpdesk_assigned_to', project])

    helpdesk_ticket = HelpdeskTicket.new(from_address: slice_emails(container.from_addr.downcase.to_s),
                                         to_address: slice_emails(email.to_addrs.join(',').downcase.to_s),
                                         cc_address: slice_emails((to_recipients + except_service_emails(email.cc_addrs)).join(',').downcase.to_s),
                                         ticket_date: email.date || Time.now,
                                         message_id: email.message_id.to_s.slice(0, 255),
                                         is_incoming: true,
                                         customer: contact,
                                         issue: issue,
                                         source: HelpdeskTicket::HELPDESK_EMAIL_SOURCE)
    issue.helpdesk_ticket = helpdesk_ticket

    add_attachments(issue)
    save_email_as_calendar(issue)
    save_email_as_attachment(helpdesk_ticket)

    Redmine::Hook.call_hook(:helpdesk_mailer_receive_issue_before_save, { issue: issue, contact: contact, helpdesk_ticket: helpdesk_ticket, email: email })

    ActiveRecord::Base.transaction do
      issue.reload if issue.persisted?
      issue.save!(validate: false)
      container.issue = issue.reload
      HelpdeskMailRule.apply_rules(:incoming, container)

      add_contact_note(issue) && send_auto_answer(issue)

      logger.try(:info, "#{email.message_id}: issue ##{issue.id} created by #{container.from_user} for #{contact.name}")
      issue
    end
  end

  private

  def add_contact_note(issue)
    return true if HelpdeskSettings['helpdesk_add_contact_notes', issue.project].to_i == 0
    ContactNote.create(content: "*#{issue.subject}* [#{issue.tracker.name} - ##{issue.id}]\n\n" + issue.description,
                       type_id: Note.note_types[:email],
                       source: contact,
                       author_id: issue.author_id)
  end

  def send_auto_answer(issue)
    return true if HelpdeskSettings['helpdesk_send_notification', issue.project].to_i == 0

    notification = HelpdeskMailer.auto_answer(contact, issue, to_address: slice_emails(container.from_addr.downcase.to_s))
    logger.try(:info, "#{email.message_id}: notification was sent to #{notification.to_addrs.first}") if notification
  rescue Exception => e
    logger.try(:error, "#{email.message_id}: notification was not sent #{e.message}")
  end

  def helpdesk_issue_attributes(issue)
    attrs = {
      'status_id' => status_id,
      'priority_id' => priority_id,
      'category_id' => category_id(issue),
      'assigned_to_id' => assigned_to_id(issue),
      'fixed_version_id' => version_id(issue),
      'start_date' => start_date,
      'due_date' => due_date,
      'estimated_hours' => estimated_hours,
      'done_ratio' => done_ratio,
      'is_private' => is_private,
      'parent_issue_id' => parent_issue_id,
    }.delete_if { |_k, v| v.blank? }

    attrs
  end

  def helpdesk_custom_field_values(customized)
    customized.custom_field_values.inject({}) do |h, v|
      if value = get_keyword(v.custom_field.name, override: true)
        h[v.custom_field.id.to_s] = value
      end
      h
    end
  end

  def tracker_id(issue)
    issue.project.trackers.named(get_keyword(:tracker, override: true)).map(&:id).first ||
      issue.project.trackers.where(id: get_keyword(:tracker_id)).first.try(:id) ||
      issue.project.trackers.first.try(:id)
  end

  def status_id
    IssueStatus.named(get_keyword(:status)).map(&:id).first || IssueStatus.where(id: get_keyword(:status_id)).first.try(:id)
  end

  def priority_id
    IssuePriority.named(get_keyword(:priority)).map(&:id).first || IssuePriority.where(id: get_keyword(:priority_id)).first.try(:id)
  end

  def category_id(issue)
    key = get_keyword(:category, override: true).try(:squish)
    issue.project.issue_categories.named(key).map(&:id).first if key
  end

  def assigned_to_id(issue)
    key = get_keyword(:assigned_to, override: true).try(:squish) || get_keyword(:assigned_to_id, override: true)
    assigned = Principal.detect_by_keyword(issue.assignable_users, key) || User.where(id: key).first
    assigned ||= Group.where(id: key).first if Setting.issue_group_assignment? && key
    assigned.try(:id)
  end

  def version_id(issue)
    issue.project.shared_versions.named(get_keyword(:fixed_version, override: true)).map(&:id).first
  end

  def start_date
    get_keyword(:start_date, override: true, format: '\d{4}-\d{2}-\d{2}')
  end

  def due_date
    get_keyword(:due_date, override: true, format: '\d{4}-\d{2}-\d{2}')
  end

  def estimated_hours
    get_keyword(:estimated_hours, override: true)
  end

  def done_ratio
    get_keyword(:done_ratio, override: true, format: '(\d|10)?0')
  end

  def is_private
    get_keyword(:is_private, override: true)
  end

  def parent_issue_id
    get_keyword(:parent_issue, override: true)
  end

  def cleaned_up_subject(email)
    return '' if email[:subject].blank?
    subject = decode_subject(email[:subject].respond_to?(:unparsed_value) ? email[:subject].unparsed_value : email[:subject].value)
    subject = HelpdeskMailSupport.convert_to_utf8(subject)
    subject.gsub!(/./) { |c| c.bytesize == 4 ? '' : c }
    subject.strip[0, 255]
  rescue Exception => e
    logger.try(:error, "#{email.message_id}: Message subject processing error - #{e.message}")
    '(Unprocessable subject)'
  end

  def decode_subject(str)
    # Optimization: If there's no encoded-words in the string, just return it
    return str unless str.index('=?')

    str = str.gsub(/\?=(\s*)=\?/, '?=????=?') # Replace whitespaces between 'encoded-word's on special symbols
    str.split('????').map do |text|
      if text.index('=?') .nil?
        text
      else
        text.gsub!(/[\r\n]/, '')
        text.gsub(/\=\?.+?\?[qQbB]\?.+?\?\=/) do |part|
          if part.index(/\=\?.+\?[Bb]\?.+\?\=/m)
            part.gsub(/\=\?.+\?[Bb]\?.+\?=/m) { |substr| Mail::Encodings.b_value_decode(substr) }
          elsif part.index(/\=\?.+\?[Qq]\?.+\?\=/m)
            part.gsub(/\=\?.+\?[Qq]\?.+\?\=/m) { |substr| Mail::Encodings.q_value_decode(substr) }
          end
        end
      end
    end.join('')
  end
end
