# This file is a part of Redmine Helpdesk (redmine_helpdesk) plugin,
# customer support management plugin for Redmine
#
# Copyright (C) 2011-2024 RedmineUP
# http://www.redmineup.com/
#
# redmine_helpdesk is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_helpdesk is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_helpdesk.  If not, see <http://www.gnu.org/licenses/>.

module RedmineHelpdesk
  module MailRules
    module Actions
      class DueDate < BaseAction
        def field
          'due_date'
        end

        def options
          {
            type: :date_with_labels,
            name: l(:label_helpdesk_mail_rule_action_issue_due_date)
          }
        end

        def values(_rule_instance = nil)
          return []
        end

        def label_for(action_options)
          value = action_options[:values].join(',')
          case action_options[:operator]
          when '='
            value
          when 't'
            l(:label_today)
          when 'nd'
            l(:label_tomorrow)
          when 'da'
            l(:label_helpdesk_days_after_full, days: value)
          end
        end

        def apply(container, operator, value)
          value = value.join
          due_date =
            case operator
            when '='
              Date.parse(value)
            when 't'
              Date.today
            when 'nd'
              Date.tomorrow
            when 'da'
              Date.today + value.to_i.days
            end
          container.issue.update_column(:due_date, due_date)
        end
      end
    end
  end
end

HelpdeskMailRule.add_action(RedmineHelpdesk::MailRules::Actions::DueDate)
