# This file is a part of Redmine Helpdesk (redmine_helpdesk) plugin,
# customer support management plugin for Redmine
#
# Copyright (C) 2011-2024 RedmineUP
# http://www.redmineup.com/
#
# redmine_helpdesk is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_helpdesk is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_helpdesk.  If not, see <http://www.gnu.org/licenses/>.

module RedmineHelpdesk
  module MailRules
    module Actions
      class IssueStatus < BaseAction
        def field
          'issue_status'
        end

        def options
          {
            type: :list,
            name: l(:label_helpdesk_mail_rule_action_issue_status)
          }
        end

        def values(_rule_instance = nil)
          ::IssueStatus.all.map { |status| [status.name, status.id.to_s] }
        end

        def label_for(action_options)
          value = action_options[:values].join(',')
          values.detect { |val| val.last == value }.try(:first)
        end

        def apply(container, operator, value)
          status = ::IssueStatus.where(id: value.join.to_i).first
          return if container.nil? || container.issue.nil? || status.nil?
          container.issue.update_column(:status_id, status.id)
        end
      end
    end
  end
end

HelpdeskMailRule.add_action(RedmineHelpdesk::MailRules::Actions::IssueStatus)
