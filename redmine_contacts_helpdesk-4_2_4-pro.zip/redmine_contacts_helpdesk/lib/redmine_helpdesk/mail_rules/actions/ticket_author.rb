# This file is a part of Redmine Helpdesk (redmine_helpdesk) plugin,
# customer support management plugin for Redmine
#
# Copyright (C) 2011-2024 RedmineUP
# http://www.redmineup.com/
#
# redmine_helpdesk is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_helpdesk is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_helpdesk.  If not, see <http://www.gnu.org/licenses/>.

module RedmineHelpdesk
  module MailRules
    module Actions
      class TicketAuthor < BaseAction
        def field
          'ticker_author'
        end

        def options
          {
            type: :ticker_author,
            name: 'Set ticket author from email body (##user@domain.com##)'
          }
        end

        def values(_rule_instance = nil)
          []
        end

        def label_for(action_options)
          'Author from email body (##user@domain.com##)'
        end

        def apply(container, operator, value)
          return if container.nil? || container.issue.nil? || container.issue.helpdesk_ticket.nil?

          contact_email = container.text_body.scan(/##(.+?)##/).flatten.first
          contact = Contact.find_by_emails([contact_email]).first
          if contact_email && contact
            container.issue.helpdesk_ticket.from_address = contact_email
            container.issue.helpdesk_ticket.customer = contact
            container.issue.helpdesk_ticket.save
          end
        end
      end
    end
  end
end

HelpdeskMailRule.add_action(RedmineHelpdesk::MailRules::Actions::TicketAuthor)
