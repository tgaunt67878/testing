# This file is a part of Redmine Helpdesk (redmine_helpdesk) plugin,
# customer support management plugin for Redmine
#
# Copyright (C) 2011-2024 RedmineUP
# http://www.redmineup.com/
#
# redmine_helpdesk is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_helpdesk is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_helpdesk.  If not, see <http://www.gnu.org/licenses/>.

module RedmineHelpdesk
  module MailRules
    module Conditions
      class MessageBody < BaseCondition
        def field
          'message_body'
        end

        def options
          {
            type: :string,
            name: l(:label_helpdesk_mail_rule_condition_message_body)
          }
        end

        def check(container, operator, values)
          message_body = container.try(:text_body)
          return false if message_body.nil? || !message_body.is_a?(String)
          value = values.join
          case operator
          when '='
            message_body == value
          when '~'
            if value.include?(',')
              value.split(',').all? { |val| message_body.downcase.include?(val.downcase) }
            elsif value.include?('|')
              value.split('|').any? { |val| message_body.downcase.include?(val.downcase) }
            else
              message_body.downcase.include?(value.downcase)
            end
          when '!'
            message_body != value
          when '!~'
            !message_body.downcase.include?(value.downcase)
          when '!*'
            message_body.blank?
          when '*'
            message_body.present?
          when '^'
            message_body.match(/^#{value}/)
          when '$'
            message_body.match(/#{value}$/)
          else
            false
          end
        end
      end
    end
  end
end

HelpdeskMailRule.add_condition(RedmineHelpdesk::MailRules::Conditions::MessageBody)
