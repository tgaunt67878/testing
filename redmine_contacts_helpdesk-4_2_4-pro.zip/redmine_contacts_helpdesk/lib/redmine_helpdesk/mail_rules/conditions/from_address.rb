# This file is a part of Redmine Helpdesk (redmine_helpdesk) plugin,
# customer support management plugin for Redmine
#
# Copyright (C) 2011-2024 RedmineUP
# http://www.redmineup.com/
#
# redmine_helpdesk is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_helpdesk is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_helpdesk.  If not, see <http://www.gnu.org/licenses/>.

module RedmineHelpdesk
  module MailRules
    module Conditions
      class FromAddress < BaseCondition
        def field
          'from_address'
        end

        def options
          {
            type: :string,
            name: l(:label_helpdesk_mail_rule_condition_from_address)
          }
        end

        def check(container, operator, values)
          from_addr = container.try(:from_addr)
          return false if from_addr.nil? || !from_addr.is_a?(String)
          value = values.join
          case operator
          when '='
            from_addr == value
          when '~'
            if value.include?(',')
              value.split(',').all? { |val| from_addr.downcase.include?(val.downcase) }
            elsif value.include?('|')
              value.split('|').any? { |val| from_addr.downcase.include?(val.downcase) }
            else
              from_addr.downcase.include?(value.downcase)
            end
          when '!'
            from_addr != value
          when '!~'
            !from_addr.downcase.include?(value.downcase)
          when '!*'
            from_addr.blank?
          when '*'
            from_addr.present?
          when '^'
            from_addr.match(/^#{value}/)
          when '$'
            from_addr.match(/#{value}$/)
          else
            false
          end
        end
      end
    end
  end
end

HelpdeskMailRule.add_condition(RedmineHelpdesk::MailRules::Conditions::FromAddress)
