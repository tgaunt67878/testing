# This file is a part of Redmine Helpdesk (redmine_helpdesk) plugin,
# customer support management plugin for Redmine
#
# Copyright (C) 2011-2024 RedmineUP
# http://www.redmineup.com/
#
# redmine_helpdesk is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_helpdesk is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_helpdesk.  If not, see <http://www.gnu.org/licenses/>.

class HelpdeskTicketDrop < Liquid::Drop
  delegate :message_id,
          :is_incoming,
          :from_address,
          :to_address,
          :cc_address,
          :ticket_date,
          :vote,
          :vote_comment,
          to: :@ticket,
          allow_nil: true

  def initialize(issue)
    @issue = issue
    @ticket = @issue.helpdesk_ticket
  end

  def reaction_time
    @reaction_time ||= @ticket.reaction_time.to_i / 60 if @ticket
  end

  def first_response_time
    @first_response_time ||= @ticket.first_response_time.to_i / 60 if @ticket
  end

  def resolve_time
    @resolve_time ||= @ticket.resolve_time.to_i / 60 if @ticket
  end

  def customer
    return if !defined?(::Contact) || @ticket.nil?

    ContactDrop.new(@ticket.customer)
  end

  def messages
    @issue.journals.joins(:journal_message).map { |journal| JournalMessageDrop.new(journal) }
  end
end

class JournalMessageDrop < Liquid::Drop
  delegate :is_incoming,
          :to_address,
          :bcc_address,
          :cc_address,
          :message_id,
          to: :@message

  delegate :notes, :private_notes,:created_on, to: :@journal

  def initialize(journal)
    @journal = journal
    @message = @journal.journal_message
  end

  def user
    @user ||= UserDrop.new(@journal.user)
  end
end
