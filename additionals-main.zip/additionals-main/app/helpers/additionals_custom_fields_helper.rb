# frozen_string_literal: true

module AdditionalsCustomFieldsHelper
  def custom_fields_with_full_with_layout
    ['IssueCustomField']
  end
end
