# frozen_string_literal: true

# Activate n+1 tests, if true
# TODO: this is disabled at the moment
Bullet.enable = false if defined? Bullet
