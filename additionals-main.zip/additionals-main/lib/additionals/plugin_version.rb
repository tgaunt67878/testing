# frozen_string_literal: true

module Additionals
  module PluginVersion
    VERSION = '3.3.0-main' unless defined? Additionals::PluginVersion::VERSION
  end
end
