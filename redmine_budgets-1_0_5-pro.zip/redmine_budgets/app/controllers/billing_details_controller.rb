# This file is a part of Redmin Budgets (redmine_budgets) plugin,
# Filse storage plugin for redmine
#
# Copyright (C) 2011-2024 RedmineUP
# http://www.redmineup.com/
#
# redmine_budgets is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_budgets is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_budgets.  If not, see <http://www.gnu.org/licenses/>.

class BillingDetailsController < ApplicationController
  before_action :find_project_by_project_id, only: :update_project_billing_detail
  before_action :find_issue_by_issue_id, only: [:edit_issue_billing_detail, :update_issue_billing_detail]
  before_action :authorize, except: [:show, :create,:update, :destroy]

  accept_api_auth :show, :create, :update, :destroy

  def update_project_billing_detail
    @billing_detail = @project.billing_settings
    @billing_detail.safe_attributes = params[:billing_settings]
    @billing_detail.nullify_billing_settings_extra_attributes

    if @billing_detail.save
      flash[:notice] = l(:notice_successful_update)
      render js: "window.location = '#{settings_project_path(@project, 'billing-details')}'"
    else
      render :edit_project_billing_detail
    end
  end

  def edit_issue_billing_detail
    @billing_detail = @issue.billing_settings
  end

  def update_issue_billing_detail
    @billing_detail = @issue.billing_settings
    @billing_detail.safe_attributes = params[:billing_settings]
    @billing_detail.assign_issue_expenses(params[:issue_expenses])

    render :edit_issue_billing_detail unless @billing_detail.save
  end

  def index
    respond_to do |format|
      format.api do
        @billing_details = BillingDetail.all
        @billing_details_count = @billing_details.count
      end
    end
  end

  def show
    @billing_detail = BillingDetail.find_by(
        id: params[:id],
        billable_id: params[:issue_id]
    ) if params[:issue_id]

    @billing_detail = BillingDetail.find_by(
        id: params[:id],
        billable_id: params[:project_id]
    ) if params[:project_id]

    unless @billing_detail
      render_404
    end

    respond_to do |format|
      format.api do
        @billing_detail
      end
    end
  end

  def create
    unless params[:project_id].nil?
      project = Project.find_by(id: params[:project_id])
      @billing_detail = project.billing_settings
      @billing_detail.safe_attributes = params[:billing_settings]
      @billing_detail.nullify_billing_settings_extra_attributes
    end

    unless params[:issue_id].nil?
      issue = Issue.find_by(id: params[:issue_id])
      @billing_detail = issue.billing_settings
      @billing_detail.safe_attributes = params[:billing_settings]
      @billing_detail.assign_issue_expenses(params[:issue_expenses])
    end

    if @billing_detail.save
      respond_to do |format|
        format.api do
          render_api_ok
        end
      end
    else
      respond_to do |format|
        format.api do
          render_validation_errors(@billing_detail)
        end
      end
    end

  end

  def update
    unless params[:project_id].nil?
      project = Project.find_by(id: params[:project_id])

      @billing_detail = project.billing_settings
      @billing_detail.safe_attributes = params[:billing_settings]
      @billing_detail.nullify_billing_settings_extra_attributes
    end

    unless params[:issue_id].nil?
      issue = Issue.find_by(id: params[:issue_id])

      @billing_detail = issue.billing_settings
      @billing_detail.safe_attributes = params[:billing_settings]
      @billing_detail.assign_issue_expenses(params[:issue_expenses])
    end

    if @billing_detail.save
      respond_to do |format|
        format.api do
          render_api_ok
        end
      end
    else
      respond_to do |format|
        format.api do
          render_validation_errors(@billing_detail)
        end
      end
    end
  end

  def destroy
    unless params[:project_id].nil?
      project = Project.find_by(id: params[:project_id])
      @billing_detail = project.billing_detail
      if @billing_detail.destroy
        respond_to do |format|
          format.api do
            render_api_ok
          end
        end
      end
    end

    unless params[:issue_id].nil?
      issue = Issue.find_by(id: params[:issue_id])
      @billing_detail = issue.billing_detail
      if @billing_detail.destroy
        respond_to do |format|
          format.api do
            render_api_ok
          end
        end
      end
    end
  end

  private

  def find_issue_by_issue_id
    @issue = Issue.find(params[:issue_id])
    raise Unauthorized unless @issue.visible?
    @project = @issue.project
  rescue ActiveRecord::RecordNotFound
    render_404
  end
end
