# This file is a part of Redmin Budgets (redmine_budgets) plugin,
# Filse storage plugin for redmine
#
# Copyright (C) 2011-2024 RedmineUP
# http://www.redmineup.com/
#
# redmine_budgets is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_budgets is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_budgets.  If not, see <http://www.gnu.org/licenses/>.

class UserRatesController < ApplicationController
  before_action :require_login, except: [:index, :show]
  before_action :find_user_by_user_id
  before_action :check_permissions, except: [:index, :show]
  before_action :find_user_rate, only: [:show, :edit, :update, :destroy]

  accept_api_auth :index, :show, :create, :update, :destroy

  def index
    respond_to do |format|
      format.api do
        @user_rates = UserRate.where(user_id: @user.id).order(:id)
        @user_rates_count = @user_rates.count
      end
    end
  end

  def new
    @user_rate = UserRate.new(from_date: Date.today)
  end

  def show
    respond_to do |format|
      format.api do
        @user_rate
      end
    end
  end

  def edit
  end

  def create
    @user_rate = UserRate.new(user_id: @user.id)
    @user_rate.safe_attributes = params[:user_rate]

    if @user_rate.save
      respond_to do |format|
        format.html do
          flash[:notice] = l(:notice_successful_create)
          redirect_to edit_user_rates_tab_path(@user)
        end
        format.api do
          render :action => 'show', :status => :created
        end
      end
    else
      respond_to do |format|
        format.html do
          render :new
        end
        format.api do
          render_validation_errors(@user_rate)
        end
      end
    end
  end

  def update
    @user_rate.safe_attributes = params[:user_rate]
    if @user_rate.save
      respond_to do |format|
        format.html do
          flash[:notice] = l(:notice_successful_update)
          redirect_to edit_user_rates_tab_path(@user)
        end
        format.api do
          render_api_ok
        end
      end
    else
      respond_to do |format|
        format.html do
          render :edit
        end
        format.api do
          render_validation_errors(@user_rate)
        end
      end
    end
  end

  def destroy
    if @user_rate.destroy
      respond_to do |format|
        format.html do
          redirect_to edit_user_rates_tab_path(@user), notice: l(:notice_user_rate_successfully_destroyed)
        end
        format.api do
          render_api_ok
        end
      end
    end
  end

  private

  def find_user_by_user_id
    @user = User.find(params[:user_id])
  rescue ActiveRecord::RecordNotFound
    render_404
  end

  def find_user_rate
    @user_rate = UserRate.find(params[:id])
  end

  def check_permissions
    render_403 unless User.current.allowed_to_edit_user_rates?(@user)
  end

  def edit_user_rates_tab_path(user)
    edit_user_path(user, tab: 'rates')
  end
end
