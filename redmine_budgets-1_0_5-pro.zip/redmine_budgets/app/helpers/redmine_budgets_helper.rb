# encoding: utf-8
#
# This file is a part of Redmin Budgets (redmine_budgets) plugin,
# Filse storage plugin for redmine
#
# Copyright (C) 2011-2024 RedmineUP
# http://www.redmineup.com/
#
# redmine_budgets is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_budgets is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_budgets.  If not, see <http://www.gnu.org/licenses/>.

module RedmineBudgetsHelper
  def hours_with_minutes(time, label_hour = l(:label_budgets_hour_letter), label_minute = l(:label_budgets_minute_letter))
    "#{time.to_i}#{label_hour} #{(60 * (time % 1)).round}#{label_minute}".html_safe
  end

  def time_metric_label(time)
    content_tag :div, class: 'num' do
      hours_with_minutes(time, "<span>#{l(:label_budgets_hour_letter)}</span>", "<span>#{l(:label_budgets_minute_letter)}</span>")
    end
  end

  def budget_value(project)
    if project.time_budget?
      l_hours_short_value(project.hours_budget)
    else
      price_to_currency(project.money_budget)
    end
  end

  def remaining_budget_value(project)
    if project.time_budget?
      l_hours_short_value(project.remaining_hours)
    else
      money_value(project.remaining_money)
    end
  end
end
