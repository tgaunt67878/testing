# This file is a part of Redmin Budgets (redmine_budgets) plugin,
# Filse storage plugin for redmine
#
# Copyright (C) 2011-2024 RedmineUP
# http://www.redmineup.com/
#
# redmine_budgets is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_budgets is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_budgets.  If not, see <http://www.gnu.org/licenses/>.

module RedmineBudgets
  VIEW_OWN_RATES_PERMISSION = 'view_own_rates'.freeze
  VIEW_RATES_PERMISSION = 'view_rates'.freeze
  EDIT_RATES_PERMISSION = 'edit_rates'.freeze

  AVAILABLE_RATES_PERMISSIONS = [
    VIEW_OWN_RATES_PERMISSION,
    VIEW_RATES_PERMISSION,
    EDIT_RATES_PERMISSION
  ].freeze

  def self.settings
    Setting.plugin_redmine_budgets
  end

  def self.company_bill_rate
    settings['company_bill_rate'].to_f
  end

  def self.people_plugin_installed?
    @@people_plugin_installed ||= file_exist?(Rails.root.join('plugins/redmine_people'))
  end

  def self.contacts_invoices_plugin_installed?
    @@contacts_invoices_plugin_installed ||= file_exist?(Rails.root.join('plugins/redmine_contacts_invoices'))
  end

  def self.load_patches
    base_url = File.dirname(__FILE__)
    REDMINE_BUDGETS_REQUIRED_FILES.each { |file| require(base_url + '/' + file) }
  end

  def self.file_exist?(file_path)
    File.respond_to?(:exist?) ? File.exist?(file_path) : File.exist?(file_path)
  end
end

REDMINE_BUDGETS_REQUIRED_FILES = [
  'redmine_budgets/utils/user_rates_calculation',
  'redmine_budgets/helpers/budgets_helper',
  'redmine_budgets/hooks/views_projects_hook',
  'redmine_budgets/hooks/views_issues_hook',
  'redmine_budgets/hooks/views_users_hook',
  'redmine_budgets/patches/projects_helper_patch',
  'redmine_budgets/patches/users_helper_patch',
  'redmine_budgets/patches/time_entry_query_patch',
  'redmine_budgets/patches/issue_query_patch',
  'redmine_budgets/patches/project_patch',
  'redmine_budgets/patches/issue_patch',
  'redmine_budgets/patches/user_patch',
  'redmine_budgets/patches/user_preference_patch',
  'redmine_budgets/hooks/views_expenses_hook',
  'redmine_budgets/patches/expense_patch',
  'redmine_budgets/patches/expenses_helper_patch',
  'redmine_budgets/patches/auto_completes_controller_patch',
  'redmine_budgets/patches/projects_controller_patch'
]

Redmine::VERSION.to_s >= '5' ? RedmineBudgets.load_patches : Rails.application.config.after_initialize { RedmineBudgets.load_patches }
