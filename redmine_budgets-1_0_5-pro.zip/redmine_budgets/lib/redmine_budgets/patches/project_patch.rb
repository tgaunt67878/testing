# This file is a part of Redmin Budgets (redmine_budgets) plugin,
# Filse storage plugin for redmine
#
# Copyright (C) 2011-2024 RedmineUP
# http://www.redmineup.com/
#
# redmine_budgets is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_budgets is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_budgets.  If not, see <http://www.gnu.org/licenses/>.

module RedmineBudgets
  module Patches
    module ProjectPatch
      def self.included(base)
        base.class_eval do
          include RedmineBudgets::Utils::UserRatesCalculation
          include InstanceMethods

          has_one :billing_detail, as: :billable, dependent: :destroy

          delegate *BillingSettingsAttributes::PROJECT_SETTINGS_ATTRIBUTES, to: :billing_settings
        end
      end

      module InstanceMethods
        def default_billing_settings
          BillingDetail.new(
            billable: self,
            settings: {
              billing_type: BillingDetail::BILLING_TYPE_NOT_BILLABLE,
              bill_rate_type: BillingDetail::BILL_RATE_BY_USER,
              budget_type: BillingDetail::BUDGET_TYPE_NO_BUDGET
            }
          )
        end

        def billing_settings
          @billing_settings ||= billing_detail || default_billing_settings
        end

        def allowed_to_edit?(attribute)
          case attribute.to_sym
          when :bill_rate_type
            billing_type_time_and_materials?
          when :bill_rate
            billing_type_time_and_materials? && bill_rate_by_project?
          when :project_cost
            
            billing_type_project_flat_rate? && !issues_fee_budget?
          else
            allowed_attribute?(attribute)
          end
        end

        def allowed_attribute?(attribute)
          BillingSettingsAttributes::PROJECT_SETTINGS_ATTRIBUTES.include?(attribute.to_sym)
        end

        def billable?
          billing_type != BillingDetail::BILLING_TYPE_NOT_BILLABLE
        end

        def non_billable?
          !billable?
        end

        def billing_type_time_and_materials?
          billing_type == BillingDetail::BILLING_TYPE_TIME_AND_MATERIALS
        end
        def billing_type_issue_flat_rate?
          billing_type == BillingDetail::BILLING_TYPE_ISSUE_FLAT_RATE
        end

        def billing_type_project_flat_rate?
          billing_type == BillingDetail::BILLING_TYPE_PROJECT_FLAT_RATE
        end

        def no_budget?
          budget_type == BillingDetail::BUDGET_TYPE_NO_BUDGET
        end

        def project_fee_budget?
          budget_type == BillingDetail::BUDGET_TYPE_PROJECT_FEE
        end

        def issues_fee_budget?
          budget_type == BillingDetail::BUDGET_TYPE_ISSUES_FEE
        end

        def issues_time_budget?
          budget_type == BillingDetail::BUDGET_TYPE_ISSUES_TIME
        end

        def project_time_budget?
          budget_type == BillingDetail::BUDGET_TYPE_PROJECT_TIME
        end
        def monthly_budget?
          monthly_budget == '1'
        end

        def money_budget?
          issues_fee_budget? || project_fee_budget?
        end

        def time_budget?
          issues_time_budget? || project_time_budget?
        end

        def bill_rate_by_project?
          bill_rate_type == BillingDetail::BILL_RATE_BY_PROJECT
        end

        def bill_rate_by_issue?
          bill_rate_type == BillingDetail::BILL_RATE_BY_ISSUE
        end

        def billable_issues
          @billable_issues ||=
            issues.
              includes(:billing_detail, :time_entries, project: :billing_detail).
              select(&:billable?)
        end

        def spent_hours
          @spent_hours ||= monthly_budget? ? monthly_hours : total_spent_hours
                  end

        def total_spent_hours
          @total_spent_hours ||= time_entries.sum(:hours)
        end

        def billable_hours
          @billable_hours ||= billable_time_entries.sum(:hours)
        end

        def non_billable_hours
          @non_billable_hours ||= total_spent_hours - billable_hours
        end

        def estimated_hours
          @estimated_hours ||= issues.sum(:estimated_hours)
        end
        def expenses_amount
          return 0 unless RedmineBudgets.contacts_invoices_plugin_installed?

          @expenses_amount ||=
            Expense.for_default_currency
            .where(id: ExpenseIssueLink.where(billing_detail: BillingDetail.where(billable: project.issues)).pluck(:expense_id))
            .sum(:price).to_f
        end

        def costs
          @costs ||= time_entries.to_a.sum { |x| time_entry_costs(x) }
        end

        def monthly_costs
          @monthly_costs ||= monthly_time_entries.sum { |x| time_entry_costs(x) }
        end

        def total_costs
          @total_costs ||= costs + expenses_amount
                  end

        def billable_amount
          @billable_amount ||=
            if billing_type_time_and_materials?
              total_spent_money
            elsif billing_type_project_flat_rate? || billing_type_issue_flat_rate?
                project_cost_value
            end
        end

        def money_budget
          @money_budget ||=
            if project_fee_budget?
              budget
            elsif issues_fee_budget?
              billable_issues_budget
            end
        end

        def hours_budget
          @hours_budget ||=
            if project_time_budget?
              budget
            elsif issues_time_budget?
              estimated_hours
            end
        end

        def spent_money
          @spent_money ||=
            if allowed_to_edit?(:bill_rate_type)
              monthly_budget? ? monthly_spent_money : total_spent_money
            elsif (billing_type_project_flat_rate? || billing_type_issue_flat_rate?) && money_budget?
              monthly_budget? ? monthly_costs : costs
                          end
        end

        def spent_money_progress
          @spent_money_progress ||=
            if spent_money && money_budget
              money_budget == 0 ? 100 : spent_money * 100 / money_budget
            else
              100
            end
        end

        def spent_hours_progress
          @spent_hours_progress ||=
            if hours_budget
              hours_budget == 0 ? 100 : spent_hours * 100 / hours_budget
            else
              100
            end
        end

        def remaining_money
          @remaining_money ||= money_budget && spent_money ? money_budget - spent_money : 0
        end

        def remaining_hours
          @remaining_hours ||= hours_budget ? hours_budget - spent_hours : 0
        end

        def remaining_money_progress
          @remaining_money_progress ||= spent_money_progress ? 100 - spent_money_progress : 0
        end

        def remaining_hours_progress
          @remaining_hours_progress ||= spent_hours_progress ? 100 - spent_hours_progress : 0
        end

        def remaining_budget
          @remaining_budget ||= time_budget? ? remaining_hours : remaining_money
        end

        def remaining_budget_progress
          @remaining_budget_progress ||= time_budget? ? remaining_hours_progress : remaining_money_progress
        end

        def profit
          @profit ||= billable_amount - total_costs if billable_amount
        end

        def profit_progress
          @profit_progress ||=
            if profit
              billable_amount == 0 ? -100 : profit * 100 / billable_amount
            end
        end

        private

        def project_time_entries
          @project_time_entries ||= time_entries.where(issue_id: nil)
        end

        def billable_project_time_entrie_ids
          @billable_project_time_entrie_ids ||= (non_billable? || bill_rate_by_issue?) ? [] : project_time_entries.pluck(:id)
                  end

        def billable_issue_time_entries
          @billable_issue_time_entries ||= TimeEntry.where(issue_id: billable_issues.map(&:id))
        end

        def billable_time_entries
          @billable_time_entries ||= TimeEntry.where(id: (billable_project_time_entrie_ids + billable_issue_time_entries.ids).uniq)
        end

        def select_monthly_time_entries(time_entries)
          date = User.current.today.beginning_of_month
          time_entries.to_a.select { |x| x.spent_on >= date }
        end

        def monthly_time_entries
          @monthly_time_entries ||= select_monthly_time_entries(time_entries)
        end

        def billable_monthly_time_entries
          @billable_monthly_time_entries ||= select_monthly_time_entries(billable_time_entries)
        end

        def billable_monthly_issue_time_entries
          @billable_monthly_issue_time_entries ||= select_monthly_time_entries(billable_issue_time_entries)
        end

        def monthly_hours
          @monthly_hours ||= monthly_time_entries.sum(&:hours)
        end

        def billable_monthly_hours
          @billable_monthly_hours ||= billable_monthly_time_entries.sum(&:hours)
        end

        def billable_issues_budget
          @billable_issues_budget ||= billable_issues.map(&:budget).compact.sum
        end

        def project_cost_value
          @project_cost_value ||=
            if billing_type_project_flat_rate? && issues_fee_budget?
              billable_issues_budget
            elsif billing_type_issue_flat_rate?
              billable_issues.map(&:issue_cost).compact.sum
            else
              project_cost
            end
        end

        def monthly_spent_money
          @monthly_spent_money ||=
            case bill_rate_type
            when BillingDetail::BILL_RATE_BY_PROJECT
              billable_monthly_hours * bill_rate.to_f
            when BillingDetail::BILL_RATE_BY_ISSUE
              billable_monthly_issue_time_entries.sum { |x| x.hours * x.issue.bill_rate.to_f }
            when BillingDetail::BILL_RATE_BY_COMPANY
              billable_monthly_hours * (RedmineBudgets.company_bill_rate || 0)
            else
              billable_monthly_time_entries.sum { |x| time_entry_billable_amount(x) }
            end
                    end

        def total_spent_money
          @total_spent_money ||=
            case bill_rate_type
            when BillingDetail::BILL_RATE_BY_PROJECT
              billable_hours * bill_rate.to_f
            when BillingDetail::BILL_RATE_BY_ISSUE
              billable_issues.sum { |issue| issue.spent_time * issue.bill_rate.to_f }
            when BillingDetail::BILL_RATE_BY_COMPANY
              billable_hours * (RedmineBudgets.company_bill_rate || 0)
            else
              billable_time_entries.to_a.sum { |x| time_entry_billable_amount(x) }
            end
                    end
      end
    end
  end
end

unless Project.included_modules.include?(RedmineBudgets::Patches::ProjectPatch)
  Project.send(:include, RedmineBudgets::Patches::ProjectPatch)
end
