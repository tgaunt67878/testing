# This file is a part of Redmin Budgets (redmine_budgets) plugin,
# Filse storage plugin for redmine
#
# Copyright (C) 2011-2024 RedmineUP
# http://www.redmineup.com/
#
# redmine_budgets is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_budgets is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_budgets.  If not, see <http://www.gnu.org/licenses/>.

require_dependency 'auto_completes_controller'

module RedmineBudgets
  module Patches
    module AutoCompletesControllerPatch
      def self.included(base)
        base.send(:include, InstanceMethods)
      end

      module InstanceMethods
        DEFAULT_ISSUES_LIMIT = 30

        def linked_issues
          @linked_issues = []
          q = (params[:q] || params[:term]).to_s.strip
          scope = Issue.visible.by_project(@project)
          scope = scope.limit(params[:limit] || DEFAULT_ISSUES_LIMIT)
          scope = scope.distinct
          q.split(' ').collect { |word| scope = scope.live_search(word.gsub(/[\(\)]/, '')) } unless q.blank?
          @linked_issues = scope.to_a.sort! { |x, y| x.subject <=> y.subject }

          render layout: false, partial: 'linked_issues'
        end
        def linked_expenses
          @linked_expenses = []
          q = (params[:q] || params[:term]).to_s.strip
          scope = Expense.visible.without_linked_issues.for_default_currency
          scope = scope.limit(params[:limit] || 10)
          scope = scope.where(status_id: params[:status_id]) if params[:status_id]
          scope = scope.where(project: @project) if @project
          scope = scope.live_search(q) if q.present?
          @linked_expenses = scope.order(:status_id)

          render layout: false, partial: 'linked_expenses'
        end
      end
    end
  end
end

if RedmineBudgets.contacts_invoices_plugin_installed? &&
  AutoCompletesController.included_modules.exclude?(RedmineBudgets::Patches::AutoCompletesControllerPatch)
  AutoCompletesController.send(:include, RedmineBudgets::Patches::AutoCompletesControllerPatch)
end
