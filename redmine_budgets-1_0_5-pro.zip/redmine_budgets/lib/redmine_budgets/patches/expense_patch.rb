# This file is a part of Redmin Budgets (redmine_budgets) plugin,
# Filse storage plugin for redmine
#
# Copyright (C) 2011-2024 RedmineUP
# http://www.redmineup.com/
#
# redmine_budgets is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_budgets is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_budgets.  If not, see <http://www.gnu.org/licenses/>.

module RedmineBudgets
  module Patches
    module ExpensePatch
      def self.included(base)
        base.class_eval do
          include InstanceMethods
          has_many :expense_issue_links
          has_many :billing_details, through: :expense_issue_links

          attr_accessor :linked_issue_id
          safe_attributes 'linked_issue_id'

          before_save :assign_linked_issue

          scope :for_default_currency, -> { where(currency: Redmineup::Settings::Money.default_currency) }
          scope :without_linked_issues, -> { where("#{Expense.table_name}.id NOT IN (?)", ExpenseIssueLink.pluck(:expense_id) << 0 ) }
        end
      end

      module InstanceMethods
        def linked_issue
          billing_details.first.try(:billable)
        end

        def assign_linked_issue
          issue = Issue.where(id: linked_issue_id).first
          self.billing_details = (issue ? [BillingDetail.where(billable: issue).first_or_create] : [])
        end
      end
    end
  end
end

if RedmineBudgets.contacts_invoices_plugin_installed? &&
  Expense.included_modules.exclude?(RedmineBudgets::Patches::ExpensePatch)
  Expense.send(:include, RedmineBudgets::Patches::ExpensePatch)
end
