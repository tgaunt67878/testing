# encoding: utf-8
#
# This file is a part of Redmin Budgets (redmine_budgets) plugin,
# Filse storage plugin for redmine
#
# Copyright (C) 2011-2024 RedmineUP
# http://www.redmineup.com/
#
# redmine_budgets is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_budgets is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_budgets.  If not, see <http://www.gnu.org/licenses/>.

module RedmineBudgets
  module Helper
    def money_value(value)
      price_to_currency(
        value.round(2),
        Redmineup::Settings::Money.default_currency,
        sign_before_symbol: true
      )
    end

    def l_hours_short_value(hours)
      hours < 0 ? '-' + l_hours_short(hours.abs) : l_hours_short(hours)
    end

    def budget_progress_bar(progress, options = {})
      return progress_bar(progress, options) if progress <= 100

      closed_percent = 100 * 100 / progress
      over_limit_percent = 100 - closed_percent
      titles = options[:titles].to_a
      titles[0] = "100%" if titles[0].blank?
      titles[1] = "#{progress - 100}%" if titles[1].blank?
      content_tag(
        'table',
        content_tag(
          'tr',
          content_tag('td', '', style: "width: #{closed_percent}%;", class: 'closed', title: titles[0]) +
            content_tag('td', '', style: "width: #{over_limit_percent}%;", class: 'todo', title: titles[1])
        ),
        class: "progress progress-#{closed_percent} over-limit"
      ).html_safe
    end

    def spent_money_progress_bar(object)
      progress = object.spent_money_progress.round(2)
      format_string = "%s: %s (%.2f%%)"
      options = { titles: [format_string % [l(:label_budgets_spent),
                                            price_to_currency(object.spent_money),
                                            progress]] }

      if progress < 100
        options[:titles] << nil
        options[:titles] << format_string % [l(:label_budgets_remaining),
                                             price_to_currency(object.remaining_money),
                                             100 - progress]
      elsif progress > 100
        options[:titles] << format_string % [l(:label_budgets_over_budget),
                                             price_to_currency(object.remaining_money.abs),
                                             progress - 100]
      end

      budget_progress_bar(progress, options)
    end

    def spent_hours_progress_bar(object)
      progress = object.spent_hours_progress.round(2)
      format_string = "%s: %.2f #{l(:label_budgets_hour_letter)} (%.2f%%)"
      options = { titles: [format_string % [l(:label_budgets_spent),
                                            object.spent_hours,
                                            progress]] }

      if progress < 100
        options[:titles] << nil
        options[:titles] << format_string % [l(:label_budgets_remaining),
                                             object.remaining_hours,
                                             100 - progress]
      elsif progress > 100
        options[:titles] << format_string % [l(:label_budgets_over_budget),
                                             object.remaining_hours,
                                             progress - 100]
      end

      budget_progress_bar(progress, options)
    end

    def options_for_select_by_values(values, selected, disabled = nil)
      options_for_select(values.map { |val| [l("label_budgets_#{val}"), val ] },
                         selected: selected.to_s,
                         disabled: disabled)
    end

    def billing_type_options_for_select(selected)
      options_for_select_by_values BillingDetail::BILLING_TYPES, selected
                      end

    def bill_rate_type_options_for_select(selected)
      options_for_select_by_values BillingDetail::BILL_RATE_TYPES, selected
    end

    def budget_type_options_for_select(selected)
      options_for_select_by_values BillingDetail::BUDGET_TYPES_WITH_DELIMITER, selected, :delimiter
    end
    def select_expenses_tag(name, expenses = [], options = {})
      s = select2_tag(
        name,
        options_for_select(expenses.map { |expense| [expense.to_s, expense.id] }, expenses.map(&:id)),
        url: auto_complete_linked_expenses_path(project_id: @project),
        placeholder: '',
        multiple: true,
        containerCssClass: options[:class] || 'icon icon-document',
        width: '100%',
        include_blank: options[:include_blank],
        allow_clear: options[:allow_clear] || true
      )
      s.html_safe
    end
  end
end

ActionView::Base.send :include, RedmineBudgets::Helper
