# This file is a part of Redmin Budgets (redmine_budgets) plugin,
# Filse storage plugin for redmine
#
# Copyright (C) 2011-2024 RedmineUP
# http://www.redmineup.com/
#
# redmine_budgets is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_budgets is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_budgets.  If not, see <http://www.gnu.org/licenses/>.

module RedmineBudgets
  module Utils
    module UserRatesCalculation
      attr_writer :cost_rates_by_user_id

      def cost_rates_by_user_id
        @cost_rates_by_user_id ||= UserRate.cost_rates.group_by(&:user_id)
      end

      def bill_rates_by_user_id
        @bill_rates_by_user_id ||= UserRate.bill_rates.group_by(&:user_id)
      end

      def cost_rate_by(user_id, date = User.current.today, project_id = nil)
        find_rate(cost_rates_by_user_id[user_id], date, project_id)
      end

      def bill_rate_by(user_id, date = User.current.today, project_id = nil)
        find_rate(bill_rates_by_user_id[user_id], date, project_id)
      end

      def time_entry_cost_rate(time_entry)
        cost_rate_by(time_entry.user_id, time_entry.spent_on, time_entry.project_id)
      end

      def time_entry_bill_rate(time_entry)
        bill_rate_by(time_entry.user_id, time_entry.spent_on, time_entry.project_id)
      end

      def time_entry_costs(time_entry)
        time_entry.hours * time_entry_cost_rate(time_entry)
      end

      def time_entry_billable_amount(time_entry)
        time_entry.hours * time_entry_bill_rate(time_entry)
      end

      def issue_costs(issue)
        issue.time_entries.to_a.sum { |x| time_entry_costs(x) }
      end

      def issue_billable_amount(issue)
        issue.time_entries.to_a.sum { |x| time_entry_billable_amount(x) }
      end

      private

      def find_rate(user_rates, date, project_id)
        return 0 if user_rates.blank?

        project_rates = user_rates.group_by(&:project_id)
        user_rate = UserRate.current_rate(project_rates[project_id].to_a, date)

        if user_rate.nil? && !project_id.nil?
          user_rate = UserRate.current_rate(project_rates[nil].to_a, date)
        end

        user_rate.try(:rate).to_f
      end
    end
  end
end
