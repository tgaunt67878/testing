# encoding: utf-8
#
# This file is a part of Redmin Budgets (redmine_budgets) plugin,
# Filse storage plugin for redmine
#
# Copyright (C) 2011-2024 RedmineUP
# http://www.redmineup.com/
#
# redmine_budgets is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_budgets is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_budgets.  If not, see <http://www.gnu.org/licenses/>.

require File.expand_path('../../test_helper', __FILE__)

class TimelogControllerTest < ActionController::TestCase
  include Redmine::I18n

  fixtures :projects, :enabled_modules, :roles, :members, :member_roles, :users,
           :issues, :trackers, :enumerations, :issue_statuses

  create_fixtures(redmine_budgets_fixtures_directory, [:time_entries, :user_rates])

  def setup
    Setting.plugin_redmine_budgets = {}
    @request.session[:user_id] = 1
  end

  # Costs values: 0, 0, 0, 35, 90, 101.25, 105, 108.75, 108.75, 110, 120, 127.5, 142.5, 160, 160
  def test_index_with_costs_filter
    check_costs_filter '=', ['160'], 2
    check_costs_filter '>=', ['50'], 11
    check_costs_filter '<=', ['50'], 5
    check_costs_filter '><', ['50', '100'], 1
    check_costs_filter '!*', [''], 0
    check_costs_filter '*', [''], 16
  end

  def test_index_with_costs_filter_and_grouping
    compatible_request :get, :index, {
      group_by: 'user',
      f: ['costs'],
      op: { 'costs' => '*' },
      v: { 'costs' => [''] }
    }

    assert_response :success
    assert_select 'tr.group', 3
  end

  def test_index_with_costs_column
    compatible_request :get, :index, c: %w(project spent_on user issue comments hours costs)
    assert_response :success
    assert_select 'td.costs'
  end

  def test_index_with_costs_column_and_costs_filter
    compatible_request :get, :index, {
      c: %w(project spent_on user issue comments hours costs),
      f: ['costs'],
      op: { 'costs' => '*' },
      v: { 'costs' => [''] }
    }

    assert_response :success
    assert_select 'td.costs'
  end

  def test_index_with_costs_column_and_grouping
    compatible_request :get, :index, c: %w(project spent_on user issue comments hours costs), group_by: 'user'
    assert_response :success
    assert_select 'tr.group', 3
    assert_select 'td.costs'
  end

  def test_index_with_costs_total
    compatible_request :get, :index, t: ['costs']
    assert_response :success
    assert_select '.query-totals .total-for-costs', text: l(:field_costs) + ': 1368.75'
  end

  def test_index_with_costs_total_and_grouping
    compatible_request :get, :index, t: ['costs'], group_by: 'user'
    assert_response :success
    assert_select '.query-totals .total-for-costs', text: l(:field_costs) + ': 1368.75'
    assert_select 'tr.group', count: 3 do
      assert_select '.total-for-costs .value', text: '0.00', count: 2
      assert_select '.total-for-costs .value', text: '1368.75', count: 1
    end
  end

  def test_index_with_permission_view_costs
    @request.session[:user_id] = 2
    Role.find(1).add_permission! :view_costs

    compatible_request :get, :index, c: %w(project spent_on user issue comments hours costs)
    assert_response :success
    cost_column_should_be_selected
    assert_select 'td.costs', /\d+\.\d+/
    assert_select 'td.costs', l(:label_hidden)

    compatible_request :get, :index, project_id: 'ecookbook', c: %w(project spent_on user issue comments hours costs)
    assert_response :success
    cost_column_should_be_selected
    assert_select 'td.costs', /\d+\.\d+/
    assert_select 'td.costs', l(:label_hidden), 0

    compatible_request :get, :index, project_id: 'subproject1', c: %w(project spent_on user issue comments hours costs)
    assert_response :success
    cost_column_should_be_unavailable
  end

  def test_index_without_permission_view_costs
    @request.session[:user_id] = 2

    compatible_request :get, :index, c: %w(project spent_on user issue comments hours costs)
    assert_response :success
    cost_column_should_be_unavailable

    compatible_request :get, :index, project_id: 'ecookbook', c: %w(project spent_on user issue comments hours costs)
    assert_response :success
    cost_column_should_be_unavailable
  end
  def test_time_entry_index_should_have_billable_filter
    compatible_request :get, :index, project_id: 3
    assert_response :success
    assert_select 'select#add_filter_select' do
      assert_select '[value=?]', 'billable'
    end
  end

  def test_should_return_billable_time_entries_by_filter
    params = {
        set_filter: '1',
        project_id: '3',
        f: ['spent_on', 'billable', ''],
        op: {
            spent_on: '*',
            billable: '='
        },
        v: {
            billable: ['1']
        }
    }
    compatible_request :get, :index, params
    assert_response :success
    assert_select '#time-entry-16', 0
  end

  def test_should_return_non_billable_time_entries_by_filter
    params = {
        set_filter: '1',
        project_id: '3',
        f: ['spent_on', 'billable', ''],
        op: {
            spent_on: '*',
            billable: '='
        },
        v: {
            billable: ['0']
        }
    }
    compatible_request :get, :index, params
    assert_response :success
    assert_select '#time-entry-16'
  end

  private

  def check_costs_filter(operator, value, amount)
    compatible_request :get, :index, {
      f: ['costs'],
      op: { 'costs' => operator },
      v: { 'costs' => value }
    }

    assert_response :success
    assert_select 'tr.time-entry', amount
  end

  def cost_column_should_be_selected
    assert_select 'form#query_form' do
      assert_select '.query-columns select' do
        assert_select 'option[value=?]', 'costs', 1
      end
    end
  end

  def cost_column_should_be_unavailable
    assert_select 'td.costs', 0
    assert_select 'form#query_form' do
      assert_select '.query-columns select' do
        assert_select 'option[value=?]', 'costs', 0
      end
    end
  end
end
