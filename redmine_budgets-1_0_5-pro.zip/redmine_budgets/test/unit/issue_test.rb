# encoding: utf-8
#
# This file is a part of Redmin Budgets (redmine_budgets) plugin,
# Filse storage plugin for redmine
#
# Copyright (C) 2011-2024 RedmineUP
# http://www.redmineup.com/
#
# redmine_budgets is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_budgets is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_budgets.  If not, see <http://www.gnu.org/licenses/>.

require File.expand_path('../../test_helper', __FILE__)

class IssueTest < ActiveSupport::TestCase
  fixtures :projects, :roles, :members, :member_roles, :users,
           :trackers, :enumerations, :issue_statuses, :enabled_modules

  create_fixtures(redmine_budgets_fixtures_directory, [:issues, :time_entries, :user_rates, :billing_details])

  def setup
    Setting.plugin_redmine_budgets = {}
    @project = Project.find(1)
    @issue = Issue.find(1)
  end

  def test_should_allowed_to_edit_billing_type
    set_billing_settings_for @project, billing_type: BillingDetail::BILLING_TYPE_TIME_AND_MATERIALS
    assert @issue.allowed_to_edit?(:billing_type)

    set_billing_settings_for @project, billing_type: BillingDetail::BILLING_TYPE_ISSUE_FLAT_RATE
    assert @issue.allowed_to_edit?(:billing_type)
  end

  def test_should_not_allowed_to_edit_billing_type
    set_billing_settings_for @project, billing_type: BillingDetail::BILLING_TYPE_NOT_BILLABLE
    assert !@issue.allowed_to_edit?(:billing_type)
    set_billing_settings_for @project, billing_type: BillingDetail::BILLING_TYPE_PROJECT_FLAT_RATE
    assert !@issue.allowed_to_edit?(:billing_type)
  end
  def test_should_allowed_to_edit_bill_rate
    set_billing_settings_for @project, {
      billing_type: BillingDetail::BILLING_TYPE_TIME_AND_MATERIALS,
      bill_rate_type: BillingDetail::BILL_RATE_BY_ISSUE
    }
    assert @issue.allowed_to_edit?(:bill_rate)
  end

  def test_should_not_allowed_to_edit_bill_rate
    set_billing_settings_for @project, billing_type: BillingDetail::BILLING_TYPE_NOT_BILLABLE
    assert !@issue.allowed_to_edit?(:bill_rate)

    set_billing_settings_for @project, {
      billing_type: BillingDetail::BILLING_TYPE_TIME_AND_MATERIALS,
      bill_rate_type: BillingDetail::BILL_RATE_BY_USER
    }
    assert !@issue.allowed_to_edit?(:bill_rate)
    set_billing_settings_for @project, billing_type: BillingDetail::BILLING_TYPE_PROJECT_FLAT_RATE
    assert !@issue.allowed_to_edit?(:bill_rate)
    set_billing_settings_for @project, billing_type: BillingDetail::BILLING_TYPE_ISSUE_FLAT_RATE
    assert !@issue.allowed_to_edit?(:bill_rate)
  end

  def test_should_allowed_to_edit_budget
    set_billing_settings_for @project, {
      billing_type: BillingDetail::BILLING_TYPE_TIME_AND_MATERIALS,
      budget_type: BillingDetail::BUDGET_TYPE_ISSUES_FEE
    }
    assert @issue.allowed_to_edit?(:budget)

    set_billing_settings_for @project, {
      billing_type: BillingDetail::BILLING_TYPE_ISSUE_FLAT_RATE,
      budget_type: BillingDetail::BUDGET_TYPE_ISSUES_FEE
    }
    assert @issue.allowed_to_edit?(:budget)
  end

  def test_should_not_allowed_to_edit_budget
    set_billing_settings_for @project, {
      billing_type: BillingDetail::BILLING_TYPE_TIME_AND_MATERIALS,
      budget_type: BillingDetail::BUDGET_TYPE_NO_BUDGET
    }
    assert !@issue.allowed_to_edit?(:budget)

    set_billing_settings_for @project, {
      billing_type: BillingDetail::BILLING_TYPE_ISSUE_FLAT_RATE,
      budget_type: BillingDetail::BUDGET_TYPE_NO_BUDGET
    }
    assert !@issue.allowed_to_edit?(:budget)
  end

  def test_on_billing_type_not_billable_and_budget_type_no_budget
    set_billing_settings_for @project, {
      billing_type: BillingDetail::BILLING_TYPE_NOT_BILLABLE,
      budget_type: BillingDetail::BUDGET_TYPE_NO_BUDGET
    }

    check_attributes_for @issue, {
      costs: 532.5,
      billable_amount: nil,

      budget: nil,
      money_budget: nil,
      spent_money: nil,
      spent_money_progress: nil,
      remaining_money: nil,

      hours_budget: nil,
      spent_time: 47.5,
      spent_hours_progress: nil,
      remaining_hours: nil,

      profit: nil,
      profit_progress: nil
    }
  end

  def test_on_billing_type_not_billable_and_budget_type_project_time
    set_billing_settings_for @project, {
      billing_type: BillingDetail::BILLING_TYPE_NOT_BILLABLE,
      project_cost: 1000,
      budget_type: BillingDetail::BUDGET_TYPE_PROJECT_TIME,
      budget: 1000
    }

    check_attributes_for @issue, {
      costs: 532.5,
      billable_amount: nil,

      budget: nil,
      money_budget: nil,
      spent_money: nil,
      spent_money_progress: nil,
      remaining_money: nil,

      hours_budget: nil,
      spent_time: 47.5,
      spent_hours_progress: nil,
      remaining_hours: nil,

      profit: nil,
      profit_progress: nil
    }
  end

  def test_on_billing_type_not_billable_and_budget_type_issues_time
    set_billing_settings_for @project, {
      billing_type: BillingDetail::BILLING_TYPE_NOT_BILLABLE,
      budget_type: BillingDetail::BUDGET_TYPE_ISSUES_TIME
    }

    check_attributes_for @issue, {
      costs: 532.5,
      billable_amount: nil,

      budget: nil,
      money_budget: nil,
      spent_money: nil,
      spent_money_progress: nil,
      remaining_money: nil,

      hours_budget: 200,
      spent_time: 47.5,
      spent_hours_progress: 23.75,
      remaining_hours: 152.5,

      profit: nil,
      profit_progress: nil
    }
  end
  def test_on_billing_type_time_and_materials_and_budget_type_no_budget
    set_billing_settings_for @project, {
      billing_type: BillingDetail::BILLING_TYPE_TIME_AND_MATERIALS,
      bill_rate_type: BillingDetail::BILL_RATE_BY_PROJECT,
      bill_rate: 100,
      budget_type: BillingDetail::BUDGET_TYPE_NO_BUDGET
    }

    check_attributes_for @issue, {
      costs: 532.5,
      billable_amount: 4750,

      budget: nil,
      money_budget: nil,
      spent_money: 4750,
      spent_money_progress: nil,
      remaining_money: nil,

      hours_budget: nil,
      spent_time: 47.5,
      spent_hours_progress: nil,
      remaining_hours: nil,

      profit: 4217.5,
      profit_progress: 88.78947368421052
    }
  end

  def test_on_billing_type_time_and_materials_and_budget_type_project_fee
    set_billing_settings_for @project, {
      billing_type: BillingDetail::BILLING_TYPE_TIME_AND_MATERIALS,
      bill_rate_type: BillingDetail::BILL_RATE_BY_PROJECT,
      bill_rate: 100,
      budget_type: BillingDetail::BUDGET_TYPE_PROJECT_FEE,
      budget: 10000
    }

    check_attributes_for @issue, {
      costs: 532.5,
      billable_amount: 4750,

      budget: nil,
      money_budget: nil,
      spent_money: 4750,
      spent_money_progress: nil,
      remaining_money: nil,

      hours_budget: nil,
      spent_time: 47.5,
      spent_hours_progress: nil,
      remaining_hours: nil,

      profit: 4217.5,
      profit_progress: 88.78947368421052
    }
  end

  def test_on_billing_type_time_and_materials_and_budget_type_project_fee_and_monthly_budget
    travel_to Date.new(2017, 4, 10) do
      set_billing_settings_for @project, {
        billing_type: BillingDetail::BILLING_TYPE_TIME_AND_MATERIALS,
        bill_rate_type: BillingDetail::BILL_RATE_BY_PROJECT,
        bill_rate: 100,
        budget_type: BillingDetail::BUDGET_TYPE_PROJECT_FEE,
        budget: 3000,
        monthly_budget: '1'
      }

      check_attributes_for @issue, {
        costs: 532.5,
        billable_amount: 4750.0,

        budget: nil,
        money_budget: nil,
        spent_money: 4750,
        spent_money_progress: nil,
        remaining_money: nil,

        hours_budget: nil,
        spent_time: 47.5,
        spent_hours_progress: nil,
        remaining_hours: nil,

        profit: 4217.5,
        profit_progress: 88.78947368421052
      }
    end
  end

  def test_on_billing_type_time_and_materials_and_budget_type_issues_fee
    set_billing_settings_for @project, {
      billing_type: BillingDetail::BILLING_TYPE_TIME_AND_MATERIALS,
      bill_rate_type: BillingDetail::BILL_RATE_BY_PROJECT,
      bill_rate: 100,
      budget_type: BillingDetail::BUDGET_TYPE_ISSUES_FEE
    }

    set_billing_settings_for @issue, budget: 5000

    check_attributes_for @issue, {
      costs: 532.5,
      billable_amount: 4750,

      budget: 5000,
      money_budget: 5000,
      spent_money: 4750,
      spent_money_progress: 95,
      remaining_money: 250,

      hours_budget: nil,
      spent_time: 47.5,
      spent_hours_progress: nil,
      remaining_hours: nil,

      profit: 4217.5,
      profit_progress: 88.78947368421052
    }
  end

  def test_on_billing_type_time_and_materials_and_budget_type_project_time
    set_billing_settings_for @project, {
      billing_type: BillingDetail::BILLING_TYPE_TIME_AND_MATERIALS,
      bill_rate_type: BillingDetail::BILL_RATE_BY_PROJECT,
      bill_rate: 100,
      budget_type: BillingDetail::BUDGET_TYPE_PROJECT_TIME,
      budget: 1000
    }

    check_attributes_for @issue, {
      costs: 532.5,
      billable_amount: 4750,

      budget: nil,
      money_budget: nil,
      spent_money: 4750,
      spent_money_progress: nil,
      remaining_money: nil,

      hours_budget: nil,
      spent_time: 47.5,
      spent_hours_progress: nil,
      remaining_hours: nil,

      profit: 4217.5,
      profit_progress: 88.78947368421052
    }
  end

  def test_on_billing_type_time_and_materials_and_budget_type_project_time_and_monthly_budget
    travel_to Date.new(2017, 4, 10) do
      set_billing_settings_for @project, {
        billing_type: BillingDetail::BILLING_TYPE_TIME_AND_MATERIALS,
        bill_rate_type: BillingDetail::BILL_RATE_BY_PROJECT,
        bill_rate: 100,
        budget_type: BillingDetail::BUDGET_TYPE_PROJECT_TIME,
        budget: 1000,
        monthly_budget: '1'
      }

      check_attributes_for @issue, {
        costs: 532.5,
        billable_amount: 4750,

        budget: nil,
        money_budget: nil,
        spent_money: 4750,
        spent_money_progress: nil,
        remaining_money: nil,

        hours_budget: nil,
        spent_time: 47.5,
        spent_hours_progress: nil,
        remaining_hours: nil,

        profit: 4217.5,
        profit_progress: 88.78947368421052
      }
    end
  end

  def test_on_billing_type_time_and_materials_and_budget_type_issues_time
    set_billing_settings_for @project, {
      billing_type: BillingDetail::BILLING_TYPE_TIME_AND_MATERIALS,
      bill_rate_type: BillingDetail::BILL_RATE_BY_PROJECT,
      bill_rate: 100,
      budget_type: BillingDetail::BUDGET_TYPE_ISSUES_TIME
    }

    check_attributes_for @issue, {
      costs: 532.5,
      billable_amount: 4750,

      budget: nil,
      money_budget: nil,
      spent_money: 4750,
      spent_money_progress: nil,
      remaining_money: nil,

      hours_budget: 200,
      spent_time: 47.5,
      spent_hours_progress: 23.75,
      remaining_hours: 152.5,

      profit: 4217.5,
      profit_progress: 88.78947368421052
    }
  end

  def test_on_billing_type_time_and_materials_and_budget_type_no_budget_and_bill_rate_type_by_user
    set_billing_settings_for @project, {
      billing_type: BillingDetail::BILLING_TYPE_TIME_AND_MATERIALS,
      bill_rate_type: BillingDetail::BILL_RATE_BY_USER,
      budget_type: BillingDetail::BUDGET_TYPE_NO_BUDGET
    }

    check_attributes_for @issue, {
      costs: 532.5,
      billable_amount: 887.5,

      budget: nil,
      money_budget: nil,
      spent_money: 887.5,
      spent_money_progress: nil,
      remaining_money: nil,

      hours_budget: nil,
      spent_time: 47.5,
      spent_hours_progress: nil,
      remaining_hours: nil,

      profit: 355,
      profit_progress: 40
    }
  end
  def test_on_billing_type_time_and_materials_and_budget_type_no_budget_and_bill_rate_type_by_issue
    set_billing_settings_for @project, {
      billing_type: BillingDetail::BILLING_TYPE_TIME_AND_MATERIALS,
      bill_rate_type: BillingDetail::BILL_RATE_BY_ISSUE,
      budget_type: BillingDetail::BUDGET_TYPE_NO_BUDGET
    }

    set_billing_settings_for @issue, bill_rate: 10

    check_attributes_for @issue, {
      costs: 532.5,
      billable_amount: 475,

      budget: nil,
      money_budget: nil,
      spent_money: 475,
      spent_money_progress: nil,
      remaining_money: nil,

      hours_budget: nil,
      spent_time: 47.5,
      spent_hours_progress: nil,
      remaining_hours: nil,

      profit: -57.5,
      profit_progress: -12.105263157894736
    }
  end

  def test_on_billing_type_time_and_materials_and_budget_type_no_budget_and_bill_rate_type_by_company
    with_budgets_settings 'company_bill_rate' => 10 do
      set_billing_settings_for @project, {
        billing_type: BillingDetail::BILLING_TYPE_TIME_AND_MATERIALS,
        bill_rate_type: BillingDetail::BILL_RATE_BY_COMPANY,
        budget_type: BillingDetail::BUDGET_TYPE_NO_BUDGET
      }

      check_attributes_for @issue, {
        costs: 532.5,
        billable_amount: 475,

        budget: nil,
        money_budget: nil,
        spent_money: 475,
        spent_money_progress: nil,
        remaining_money: nil,

        hours_budget: nil,
        spent_time: 47.5,
        spent_hours_progress: nil,
        remaining_hours: nil,

        profit: -57.5,
        profit_progress: -12.105263157894736
      }
    end
  end

  ##
  # tests for BILLING_TYPE_PROJECT_FLAT_RATE

  def test_on_billing_type_project_flat_rate_and_budget_type_no_budget
    set_billing_settings_for @project, {
      billing_type: BillingDetail::BILLING_TYPE_PROJECT_FLAT_RATE,
      project_cost: 1000,
      budget_type: BillingDetail::BUDGET_TYPE_NO_BUDGET
    }

    check_attributes_for @issue, {
      costs: 532.5,
      billable_amount: nil,

      budget: nil,
      money_budget: nil,
      spent_money: nil,
      spent_money_progress: nil,
      remaining_money: nil,

      hours_budget: nil,
      spent_time: 47.5,
      spent_hours_progress: nil,
      remaining_hours: nil,

      profit: nil,
      profit_progress: nil
    }
  end

  def test_on_billing_type_project_flat_rate_and_budget_type_project_fee
    set_billing_settings_for @project, {
      billing_type: BillingDetail::BILLING_TYPE_PROJECT_FLAT_RATE,
      project_cost: 1000,
      budget_type: BillingDetail::BUDGET_TYPE_PROJECT_FEE,
      budget: 1000
    }

    check_attributes_for @issue, {
      costs: 532.5,
      billable_amount: nil,

      budget: nil,
      money_budget: nil,
      spent_money: nil,
      spent_money_progress: nil,
      remaining_money: nil,

      hours_budget: nil,
      spent_time: 47.5,
      spent_hours_progress: nil,
      remaining_hours: nil,

      profit: nil,
      profit_progress: nil
    }
  end

  def test_on_billing_type_project_flat_rate_and_budget_type_project_fee_and_monthly_budget
    travel_to Date.new(2017, 4, 10) do
      set_billing_settings_for @project, {
        billing_type: BillingDetail::BILLING_TYPE_PROJECT_FLAT_RATE,
        project_cost: 2000,
        budget_type: BillingDetail::BUDGET_TYPE_PROJECT_FEE,
        budget: 1000,
        monthly_budget: '1'
      }

      check_attributes_for @issue, {
        costs: 532.5,
        billable_amount: nil,

        budget: nil,
        money_budget: nil,
        spent_money: nil,
        spent_money_progress: nil,
        remaining_money: nil,

        hours_budget: nil,
        spent_time: 47.5,
        spent_hours_progress: nil,
        remaining_hours: nil,

        profit: nil,
        profit_progress: nil
      }
    end
  end

  def test_on_billing_type_project_flat_rate_and_budget_type_issues_fee
    set_billing_settings_for @project, {
      billing_type: BillingDetail::BILLING_TYPE_PROJECT_FLAT_RATE,
      budget_type: BillingDetail::BUDGET_TYPE_ISSUES_FEE
    }

    set_billing_settings_for @issue, budget: 1000

    check_attributes_for @issue, {
      costs: 532.5,
      billable_amount: 1000,

      budget: 1000,
      money_budget: 1000,
      spent_money: 532.5,
      spent_money_progress: 53.25,
      remaining_money: 467.5,

      hours_budget: nil,
      spent_time: 47.5,
      spent_hours_progress: nil,
      remaining_hours: nil,

      profit: 467.5,
      profit_progress: 46.75
    }
  end

  def test_on_billing_type_project_flat_rate_and_budget_type_project_time
    set_billing_settings_for @project, {
      billing_type: BillingDetail::BILLING_TYPE_PROJECT_FLAT_RATE,
      project_cost: 1500,
      budget_type: BillingDetail::BUDGET_TYPE_PROJECT_TIME,
      budget: 100
    }

    check_attributes_for @issue, {
      costs: 532.5,
      billable_amount: nil,

      budget: nil,
      money_budget: nil,
      spent_money: nil,
      spent_money_progress: nil,
      remaining_money: nil,

      hours_budget: nil,
      spent_time: 47.5,
      spent_hours_progress: nil,
      remaining_hours: nil,

      profit: nil,
      profit_progress: nil
    }
  end

  def test_on_billing_type_project_flat_rate_and_budget_type_project_time_and_monthly_budget
    travel_to Date.new(2017, 4, 10) do
      set_billing_settings_for @project, {
        billing_type: BillingDetail::BILLING_TYPE_PROJECT_FLAT_RATE,
        project_cost: 1500,
        budget_type: BillingDetail::BUDGET_TYPE_PROJECT_TIME,
        budget: 100,
        monthly_budget: '1'
      }

      check_attributes_for @issue, {
        costs: 532.5,
        billable_amount: nil,

        budget: nil,
        money_budget: nil,
        spent_money: nil,
        spent_money_progress: nil,
        remaining_money: nil,

        hours_budget: nil,
        spent_time: 47.5,
        spent_hours_progress: nil,
        remaining_hours: nil,

        profit: nil,
        profit_progress: nil
      }
    end
  end

  def test_on_billing_type_project_flat_rate_and_budget_type_issues_time
    set_billing_settings_for @project, {
      billing_type: BillingDetail::BILLING_TYPE_PROJECT_FLAT_RATE,
      project_cost: 1000,
      budget_type: BillingDetail::BUDGET_TYPE_ISSUES_TIME
    }

    check_attributes_for @issue, {
      costs: 532.5,
      billable_amount: nil,

      budget: nil,
      money_budget: nil,
      spent_money: nil,
      spent_money_progress: nil,
      remaining_money: nil,

      hours_budget: 200,
      spent_time: 47.5,
      spent_hours_progress: 23.75,
      remaining_hours: 152.5,

      profit: nil,
      profit_progress: nil
    }
  end

  ##
  # tests for BILLING_TYPE_ISSUE_FLAT_RATE

  def test_on_billing_type_issue_flat_rate_and_budget_type_no_budget
    set_billing_settings_for @project, {
      billing_type: BillingDetail::BILLING_TYPE_ISSUE_FLAT_RATE,
      budget_type: BillingDetail::BUDGET_TYPE_NO_BUDGET
    }

    check_attributes_for @issue, {
      costs: 532.5,
      billable_amount: nil,

      budget: nil,
      money_budget: nil,
      spent_money: nil,
      spent_money_progress: nil,
      remaining_money: nil,

      hours_budget: nil,
      spent_time: 47.5,
      spent_hours_progress: nil,
      remaining_hours: nil,

      profit: nil,
      profit_progress: nil
    }
  end

  def test_on_billing_type_issue_flat_rate_and_budget_type_project_fee
    set_billing_settings_for @project, {
      billing_type: BillingDetail::BILLING_TYPE_ISSUE_FLAT_RATE,
      budget_type: BillingDetail::BUDGET_TYPE_PROJECT_FEE,
      budget: 1000
    }

    check_attributes_for @issue, {
      costs: 532.5,
      billable_amount: nil,

      budget: nil,
      money_budget: nil,
      spent_money: nil,
      spent_money_progress: nil,
      remaining_money: nil,

      hours_budget: nil,
      spent_time: 47.5,
      spent_hours_progress: nil,
      remaining_hours: nil,

      profit: nil,
      profit_progress: nil
    }
  end

  def test_on_billing_type_issue_flat_rate_and_budget_type_project_fee_and_monthly_budget
    travel_to Date.new(2017, 4, 10) do
      set_billing_settings_for @project, {
        billing_type: BillingDetail::BILLING_TYPE_ISSUE_FLAT_RATE,
        budget_type: BillingDetail::BUDGET_TYPE_PROJECT_FEE,
        budget: 1000,
        monthly_budget: '1'
      }

      check_attributes_for @issue, {
        costs: 532.5,
        billable_amount: nil,

        budget: nil,
        money_budget: nil,
        spent_money: nil,
        spent_money_progress: nil,
        remaining_money: nil,

        hours_budget: nil,
        spent_time: 47.5,
        spent_hours_progress: nil,
        remaining_hours: nil,

        profit: nil,
        profit_progress: nil
      }
    end
  end

  def test_on_billing_type_issue_flat_rate_and_budget_type_issues_fee
    set_billing_settings_for @project, {
      billing_type: BillingDetail::BILLING_TYPE_ISSUE_FLAT_RATE,
      budget_type: BillingDetail::BUDGET_TYPE_ISSUES_FEE
    }

    set_billing_settings_for @issue, budget: 1000, issue_cost: 1000

    check_attributes_for @issue, {
      costs: 532.5,
      billable_amount: 1000,

      budget: 1000,
      money_budget: 1000,
      spent_money: 532.5,
      spent_money_progress: 53.25,
      remaining_money: 467.5,

      hours_budget: nil,
      spent_time: 47.5,
      spent_hours_progress: nil,
      remaining_hours: nil,

      profit: 467.5,
      profit_progress: 46.75
    }
  end

  def test_on_billing_type_issue_flat_rate_and_budget_type_project_time
    set_billing_settings_for @project, {
      billing_type: BillingDetail::BILLING_TYPE_ISSUE_FLAT_RATE,
      budget_type: BillingDetail::BUDGET_TYPE_PROJECT_TIME,
      budget: 100
    }

    check_attributes_for @issue, {
      costs: 532.5,
      billable_amount: nil,

      budget: nil,
      money_budget: nil,
      spent_money: nil,
      spent_money_progress: nil,
      remaining_money: nil,

      hours_budget: nil,
      spent_time: 47.5,
      spent_hours_progress: nil,
      remaining_hours: nil,

      profit: nil,
      profit_progress: nil
    }
  end

  def test_on_billing_type_issue_flat_rate_and_budget_type_project_time_and_monthly_budget
    travel_to Date.new(2017, 4, 10) do
      set_billing_settings_for @project, {
        billing_type: BillingDetail::BILLING_TYPE_ISSUE_FLAT_RATE,
        budget_type: BillingDetail::BUDGET_TYPE_PROJECT_TIME,
        budget: 100,
        monthly_budget: '1'
      }

      check_attributes_for @issue, {
        costs: 532.5,
        billable_amount: nil,

        budget: nil,
        money_budget: nil,
        spent_money: nil,
        spent_money_progress: nil,
        remaining_money: nil,

        hours_budget: nil,
        spent_time: 47.5,
        spent_hours_progress: nil,
        remaining_hours: nil,

        profit: nil,
        profit_progress: nil
      }
    end
  end

  def test_on_billing_type_issue_flat_rate_and_budget_type_issues_time
    set_billing_settings_for @project, {
      billing_type: BillingDetail::BILLING_TYPE_ISSUE_FLAT_RATE,
      budget_type: BillingDetail::BUDGET_TYPE_ISSUES_TIME
    }

    check_attributes_for @issue, {
      costs: 532.5,
      billable_amount: nil,

      budget: nil,
      money_budget: nil,
      spent_money: nil,
      spent_money_progress: nil,
      remaining_money: nil,

      hours_budget: 200,
      spent_time: 47.5,
      spent_hours_progress: 23.75,
      remaining_hours: 152.5,

      profit: nil,
      profit_progress: nil
    }
  end
end
