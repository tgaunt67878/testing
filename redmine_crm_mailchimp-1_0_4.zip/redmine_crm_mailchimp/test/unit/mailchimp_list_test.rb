# encoding: utf-8
#
# This file is a part of Redmine Mailchimp (redmine_crm_mailchimp) plugin,
# mailchimp integration plugin for Redmine
#
# Copyright (C) 2011-2020 RedmineUP
# http://www.redmineup.com/
#
# redmine_crm_mailchimp is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_crm_mailchimp is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_crm_mailchimp.  If not, see <http://www.gnu.org/licenses/>.

require File.expand_path('../../test_helper', __FILE__)

class MailchimpListTest < ActiveSupport::TestCase
  Struct.new('MockContact', :first_name, :last_name, :email)

  def setup
    Setting.plugin_redmine_crm_mailchimp[:api_key] = '123abc-sw8'
    params = {
      'web_id' => 'web_id',
      'name' => 'List',
      'id' => '123456'
    }
    @mailchimp_list = MailchimpList.new(params)
    # Mock contact
    @contact = Struct::MockContact.new('Ben', 'Henderson', 'email@email.ru')
    @contact_2 = Struct::MockContact.new('BOB', 'SAP', 'email2@email.ru')
  end

  def test_subscribe
    stub_request(:post, "https://sw8.api.mailchimp.com/2.0/lists/subscribe.json").
      to_return(:status => 200, :body => '{"status":"success"}', :headers => {})
    
    assert_equal "{\"status\"=>\"success\"}", @mailchimp_list.subscribe(@contact).to_s
  end

  def test_bulk_subscribe
    stub_request(:post, "https://sw8.api.mailchimp.com/2.0/lists/batch-subscribe.json").
      to_return(:status => 200, :body => '{"status":"success"}', :headers => {})
    
    assert_equal "{\"status\"=>\"success\"}", @mailchimp_list.bulk_subscribe([@contact, @contact_2]).to_s    
  end

end
