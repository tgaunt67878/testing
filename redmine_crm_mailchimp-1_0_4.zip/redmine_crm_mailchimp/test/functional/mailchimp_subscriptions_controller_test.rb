# encoding: utf-8
#
# This file is a part of Redmine Mailchimp (redmine_crm_mailchimp) plugin,
# mailchimp integration plugin for Redmine
#
# Copyright (C) 2011-2020 RedmineUP
# http://www.redmineup.com/
#
# redmine_crm_mailchimp is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_crm_mailchimp is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_crm_mailchimp.  If not, see <http://www.gnu.org/licenses/>.

require File.expand_path('../test_helper', __dir__)

class MailchimpSubscriptionsControllerTest < ActionController::TestCase
  fixtures :roles,
           :member_roles,
           :members

  ActiveRecord::FixtureSet.create_fixtures(
    Redmine::Plugin.find(:redmine_contacts).directory + '/test/fixtures/',
    [:contacts]
  )

  def setup
    stub_request(:post, "https://sw8.api.mailchimp.com/2.0/lists/list.json").
      to_return(status: 200, body: '[]', headers: {})
    @request.session[:user_id] = 1
    MailchimpContactSyncer.any_instance.stubs(:run).returns(true)
  end

  def test_create
    compatible_request :post,
                      :create,
                      list_id: 'list1',
                      contact_id: Contact.first.id
    assert_response :created
  end
end
