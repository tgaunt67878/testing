# This file is a part of Redmine Mailchimp (redmine_crm_mailchimp) plugin,
# mailchimp integration plugin for Redmine
#
# Copyright (C) 2011-2020 RedmineUP
# http://www.redmineup.com/
#
# redmine_crm_mailchimp is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_crm_mailchimp is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_crm_mailchimp.  If not, see <http://www.gnu.org/licenses/>.

require 'ostruct'

class MailchimpContactSyncer
  attr_reader :merge_fields, :list_id, :contactlikes

  # Static public
  # Enqueues job for subscribing contacts or hashes
  # responding to first_name, last_name, email
  def self.subscribe_contacts_async(list_id, contactlikes, merge_fields = {})
    SyncContactJob.perform_later(list_id, contactlikes, merge_fields)
  end

  def initialize(list_id, contactlikes, merge_fields)
    @list_id = list_id
    @contactlikes = contactlikes
    @merge_fields = merge_fields
  end

  def run
    Rails.logger.error "Unable to find list #{list_id}" unless list
    cleaned_contacts.each do |contact|
      puts "Subscribing #{contact.first_name} #{contact.last_name} #{contact.email} #{merge_fields}"
      list.subscribe(contact, merge_fields)
    end
  end

  private

  def cleaned_contacts
    @cleaned_contacts ||= contactlikes_array.compact.uniq.map do |contactlike|
      contactlike.is_a?(Contact) ? contactlike : OpenStruct.new(contactlike)
    end
  end

  def contactlikes_array
    return contactlikes if contactlikes.is_a?(Array)

    [contactlikes]
  end

  def list
    @list ||= MailchimpList.find_by_id(list_id)
  end
end
