# This file is a part of Redmine Mailchimp (redmine_crm_mailchimp) plugin,
# mailchimp integration plugin for Redmine
#
# Copyright (C) 2011-2020 RedmineUP
# http://www.redmineup.com/
#
# redmine_crm_mailchimp is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_crm_mailchimp is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_crm_mailchimp.  If not, see <http://www.gnu.org/licenses/>.

class MailchimpSubscriptionsController < ApplicationController
  def create
    return deny_access unless User.current.allowed_to?(:edit_mailchimp, nil, global: true)
    MailchimpContactSyncer.subscribe_contacts_async(
      list_id,
      contactlikes,
      merge_fields
    )
    head :created
  end

  private

  def list_id
    params[:list_id]
  end

  def contactlikes
    dry(
      params[:contact_id].split(',').map do |contact_id|
        Contact.find_by(id: contact_id)
      end.compact.uniq
    )
  end

  def dry(contacts_list)
    contacts_list.map do |contact|
      contact.attributes.slice(:first_name, :last_name, :email)
    end
  end

  def merge_fields
    params[:merge_fields]
  end
end
