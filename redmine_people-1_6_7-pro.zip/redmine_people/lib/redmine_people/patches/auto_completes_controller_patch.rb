# This file is a part of Redmine People (redmine_people) plugin,
# humanr resources management plugin for Redmine
#
# Copyright (C) 2011-2024 RedmineUP
# http://www.redmineup.com/
#
# redmine_people is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_people is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_people.  If not, see <http://www.gnu.org/licenses/>.

module RedminePeople
  module Patches
    module AutoCompletesControllerPatch
      def self.included(base)
        base.class_eval do
          include ActionView::Helpers::AssetTagHelper
          include ApplicationHelper
          include AvatarsHelper if RedminePeople.module_exists?(:AvatarsHelper)

          include InstanceMethods
        end
      end

      module InstanceMethods
        USERS_LIMIT = 10

        def people_users
          @users = User.active.sorted.like(params[:q]).limit(USERS_LIMIT)
          @users = @users.visible
          @users = @users.to_a
          render json: format_users_json(@users)
        end

        def people_tags
          options = {
            name_like: (params[:q] || params[:term]).to_s.strip,
            limit: params[:limit],
          }
          @people_tags = Person.available_tags(options)
          render json: format_people_tags_json(@people_tags)
        end

        private

        def format_users_json(users)
          users.map do |user|
            {
              id: user.id,
              text: user.name.html_safe,
              avatar: avatar(user, size: 16)
            }
          end
        end

        def format_people_tags_json(tags)
          tags.map do |people_tag|
            {
              id: people_tag.name,
              text: people_tag.name
            }
          end
        end
      end
    end
  end
end

unless AutoCompletesController.included_modules.include?(RedminePeople::Patches::AutoCompletesControllerPatch)
  AutoCompletesController.send(:include, RedminePeople::Patches::AutoCompletesControllerPatch)
end
